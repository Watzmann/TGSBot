#!/usr/local/bin/python

from Tkinter import *
from Canvas import Line,Rectangle
import sys
import string
from colormap import *
from tkFileDialog import *

class Msize:
    def __init__(self,xr=400,yr=400,xs=-2.0,ys=-1.25,xw=2.6,yw=2.6):
        self.xresolution = xr
        self.yresolution = yr
        self.cxsize = self.xresolution
        self.cysize = self.yresolution
        self.znought = 0j
        self.xstart = xs
        self.ystart = ys
        self.xwidth = xw
        self.ywidth = yw
        self.xend = self.xstart + self.xwidth
        self.yend = self.ystart + self.ywidth
        self.xdiv = self.xwidth / self.xresolution
        self.ydiv = self.ywidth / self.yresolution

    def __call__(self):
        return (self.xstart,
            self.ystart,
            self.xwidth,
            self.ywidth,
            self.xend,
            self.yend,
            self.xdiv,
            self.ydiv
        )
    def set(self,x0,y0,xw,yw):
        self.xstart = x0
        self.ystart = y0
        self.xwidth = xw
        self.ywidth = yw
        self.xend = self.xstart + self.xwidth
        self.yend = self.ystart + self.ywidth
        self.xdiv = self.xwidth / self.xresolution
        self.ydiv = self.ywidth / self.yresolution

    def __repr__(self):
        s = "xstart %s ystart %s xwidth %s ywidth %s xend %s yend %s" \
            " xdiv %s ydiv %s xresolution %s yresolution %s" % \
            (self.xstart,self.ystart,
            self.xwidth,self.ywidth,
            self.xend,self.yend,
            self.xdiv,self.ydiv,
            self.xresolution,self.yresolution)
        return s

class AboutDialog:
    def __init__(self,parent):
        self.logotxt="""Mandelbrot Cruiser
Copyright � 1999, 2000
by Ivan Van Laningham
Written for
Teach Yourself Python in 24 Hours"""
        top = self.top=Toplevel(parent)
        top["background"] = "white"
        self.i=PhotoImage(file="X_GodNLogo5.gif")
        self.lg = Label(top,text="",bd=0)
        self.lg["image"] = self.i
        self.lg.pack()
        self.l=Label(top,text=self.logotxt,bd=0,background="white")
        self.l.pack(side=LEFT)
        self.b = Button(top, text="OK", command=self.ok,
            background="#008000",foreground="white")
        self.b.pack(side=LEFT)
    
    def ok(self):
        self.top.destroy()

class Mandel:
    def __init__(self,ncolors,root):
        self.root = root
        self.debug = 0
        self.useimages = 0
        self.xstart = -2.0
        self.ystart = -1.25
        self.xwidth = 2.6
        self.ywidth = 2.6
        self.xend = self.xstart + self.xwidth
        self.yend = self.ystart + self.ywidth
        self.mdb = None
        self.waitvar = 0
        self.xresolution = 400
        self.yresolution = 400
        self.cxsize = self.xresolution
        self.cysize = self.yresolution
        self.znought = 0j
        self.xdiv = self.xwidth / self.xresolution
        self.ydiv = self.ywidth / self.yresolution
        self.calculating=0
        self.ncolors = ncolors
        self.ncolorlist = ["2",
            "4",
            "8",
            "16",
            "32",
            "64",
            "128",
            "256",
            "512",
            "1024"
        ]
        self.colormaps = {"map 1":SetupColormap0,
            "map 2":SetupColormap1,
            "map 3":SetupColormap2,
            "map 4":SetupColormap3,
            "map 5":SetupColormap4,
            "map 6":SetupColormap5,
            "map 7":SetupColormap6,
        }
        self.cmapcommand=SetupColormap
        self.cmapname = "map 1"
        self.cmap = self.cmapcommand(self.ncolors - 1)
        self.stopnow = 0
        self.mdsize=None
        self.xdrawn=None
        self.ydrawn=None
        self.zdrawn=None
        self.uxl = 0
        self.uyl = 0
        self.uil = 0
        self.progress = None
        self.progressize = 10
        self.xlab = None
        self.ylab = None
        self._label = None
        self.cv = None
        self.scX = None
        self.scY = None
        self.scZ = None
        self.x0 = None
        self.x1 = None
        self.y0 = None
        self.y1 = None
        self.zlabel = None
        self.listbox = None
        self.listbox1 = None
        self.qbutton = None
        self.cbutton = None
        self.cabutton = None
        self.rbutton = None
        self.qimg = None
        self.cimg = None
        self.caimg = None
        self.rimg = None

        self.buildMenu()

        self.buildAndSetButtons()

        self.buildNColorControl()
        self.buildCMapControl()

        self.buildXYLabels()
        self.setXYLabels()
    
        self.buildProgress()
        self.buildCanvas()

        self.waitvar = IntVar(0)
        self.root.title("Mandelbrot Cruiser")
        self.listbox.after(250,self.colorpoll)

    def setXYLabels(self,m=None):
        if m == None:
            xs = "X start %f width %f xdiv %f" % \
                (self.xstart, self.xwidth, self.xdiv)
            self.xlab["text"] = xs
            ys = "Y start %f width %f ydiv %f" % \
                (self.ystart, self.ywidth, self.ydiv)
            self.ylab["text"] = ys
            self.zlabel["text"]="Zoom:%f" % \
                (self.xwidth/self.xwidth)
        else:
            xs = "X start %f width %f xdiv %f" % \
                (m.xstart, m.xwidth, m.xdiv)
            self.xlab["text"] = xs
            ys = "Y start %f width %f ydiv %f" % \
                (m.ystart, m.ywidth, m.ydiv)
            self.ylab["text"] = ys
            self.zlabel["text"]="Zoom:%f" % (self.xwidth/m.xwidth)

    def resetter(self,event=0):
        if self.calculating:
            return
        self.xstart = -2.0
        self.ystart = -1.25
        self.xwidth = 2.6
        self.ywidth = 2.6
        self.xend = self.xstart + self.xwidth
        self.yend = self.ystart + self.ywidth
        self.xdiv = self.xwidth / self.xresolution
        self.ydiv = self.ywidth / self.yresolution
        self.mdsize=Msize(self.xresolution,self.yresolution)
        self.setXYLabels()
        self.cv.delete(ALL)
        self.progress.delete(ALL)
        self.xdrawn = None
        self.ydrawn = None
        self.zdrawn = None
        self.mdb = self.dithimage()
        self.img = self.cv.create_image(self.xresolution/2, \
            self.yresolution/2, anchor=CENTER, image=self.mdb)
        self.scX.set(self.xresolution/2)
        self.scY.set(self.yresolution/2)
        self.scZ.set(self.yresolution/2)

    def zoomer(self,event=0):
        if self.calculating:
            return
        if self.mdsize == None:
            self.mdsize=Msize(self.xresolution,self.yresolution)
        oldxw = self.xwidth
        oldyh = self.ywidth
        w = self.x1 - self.x0
        xp0 = self.x0 * self.xdiv
        xp1 = self.x1 * self.xdiv
        newxst = self.xstart + xp0
        newxe = self.xstart + xp1
        h = self.y1 - self.y0
        yp0 = self.y0 * self.ydiv
        yp1 = self.y1 * self.ydiv
        newyst = self.ystart + yp0
        newye = self.ystart + yp1

        self.mdsize.set(newxst,newyst,
            newxe - newxst,
            newye - newyst)
        self.setXYLabels(self.mdsize)

    def xliner(self,event=0):
        if self.calculating:
            return
        n=self.scX.get()
        if self.xdrawn==None:
            self.xdrawn = Line(self.cv,n,0,n,self.yresolution-1,
                fill="#ffffff")
        else:
            self.cv.coords(self.xdrawn,n,0,n,self.yresolution-1)

    def yliner(self,event=0):
        if self.calculating:
            return
        n=self.scY.get()
        if self.ydrawn==None:
            self.ydrawn = Line(self.cv,0,n,self.xresolution-1,n,
                fill="#ffffff")
        else:
            self.cv.coords(self.ydrawn,0,n,self.xresolution-1,n)

    def zliner(self,event=0):
        if self.calculating:
            return
        self.xliner()
        self.yliner()
        n=self.scZ.get()
        x=self.scX.get()
        y=self.scY.get()
        lima = min(x,y)
        limb = min(self.xresolution - x, self.yresolution - y)
        limc = min(lima,limb)
        # x and y are the coordinates of the center.
        # x0 and y0 are the upper left coordinates:
        self.x0 = x - n
        if self.x0 < 0:
            self.x0 = 0
        self.y0 = y - n
        if self.y0 < 0:
            self.y0 = 0
        # x1 and y1 are the lower right coordinates:
        w = x - self.x0
        if w > limc:
            w = limc
        self.x1 = x + w
        if self.x1 > self.xresolution-1:
            self.x1 = self.xresolution-1
        if self.x1 - self.x0 > (limc * 2):
            self.x0 = self.x1 - (limc * 2)
        h = y - self.y0
        if h > limc:
            h = limc
        self.y1 = y + h
        if self.y1 > self.yresolution - 1:
            self.y1 = self.yresolution - 1
        if self.y1 - self.y0 > (limc * 2):
            self.y0 = self.y1 - (limc * 2)
        if x == 0 or y == 0:
            self.x0 = self.y0 = 0
            self.x1 = self.y1 = self.xresolution-1
        if self.x1 - self.x0 == 0 or self.y1 - self.y0 == 0:
            self.x0 = self.y0 = 0
            self.x1 = self.y1 = self.xresolution-1
        if self.zdrawn==None:
            self.zdrawn = Rectangle(self.cv,self.x0,self.y0,
                self.x1,self.y1,outline="#ffffff")
        else:
            self.cv.coords(self.zdrawn,self.x0,self.y0,self.x1,self.y1)
        self.zoomer()

    def die(self,event=0):
        self.stopnow = 1
        self.root.quit()

    def cancel(self,event=0):
        self.stopnow = 1
        self.cv.delete(ALL)
        self.xdrawn=None
        self.ydrawn=None
        self.zdrawn=None
        self.progress.delete(ALL)
        self.mdb = self.dithimage()
        self.img = self.cv.create_image(self.xresolution/2,
            self.yresolution/2, anchor=CENTER, image=self.mdb)
        self.cv.update()

    def colorpoll(self):
        if self.calculating:
            pass
        else:
            now=self.listbox.curselection()
            nn = string.atoi(self.ncolorlist[string.atoi(now[0])])
            if nn != self.ncolors:
                self.ncolors = nn

            x = self.listbox1.curselection()
            s = x[0]
            tmname = self.listbox1.get(s)
            if tmname != self.cmapname:
                self.cmapname = tmname
                self.cmapcommand = self.colormaps[self.cmapname]
        self.listbox.after(250,self.colorpoll)

    def updateProgress(self):
        if self.stopnow:
            return
        Rectangle(self.progress,
            self.uxl,self.uyl,
            self.uxl+self.progressize - 2,self.uyl+16,
            fill=self.cmap[self.uil % self.ncolors],
            outline="",
            width=0)
        self.progress.update()
        self.uxl = self.uxl + self.progressize
        self.uil = self.uil + 1

    def waitcalc(self):
        if self.calculating:
            return
        self.cv.after(1,self.calc)
        self.cv.wait_variable(self.waitvar)

    def calc(self):
        self.waitvar.set(1)
        self.cv.delete(ALL)
        self.xdrawn=None
        self.ydrawn=None
        self.zdrawn=None
        self.progress.delete(ALL)
        self.mdb = self.dithimage()
        self.img = self.cv.create_image(self.xresolution/2,
            self.yresolution/2, anchor=CENTER, image=self.mdb)
        oldcursor = self.cv["cursor"]
        self.cv["cursor"] = "watch"
        self.calculating=1

        if self.mdsize != None:
            self.xstart,self.ystart,self.xwidth,self.ywidth, \
                self.xend, self.yend,self.xdiv,self.ydiv = \
                self.mdsize()

        x = self.xstart
        self._label["text"] = \
            "Beginning calculation with %d colors %s..." % \
            (self.ncolors,self.cmapname)
        self.cmap = self.cmapcommand(self.ncolors - 1)
        if self.ncolors < 32:
            dwell = 32
        else:
            dwell = self.ncolors
        self.scX.set(self.xresolution/2)
        self.scY.set(self.yresolution/2)
        self.scZ.set(self.yresolution/2)
        if self.debug == 0:
            for xX in range ( 0, self.xresolution ) :
                y = self.ystart
                for yY in range ( 0, self.yresolution ) :
                    c = complex(x,y)
                    z = self.znought
                    i = 0
                    for i in range ( 0, dwell ):
                        r2 = z.real * z.real
                        i2 = z.imag * z.imag
                        if (r2 + i2) > 4.0:
                            break
                        else:
                            tx = r2 - i2
                            ty = (2.0 * (z.real * z.imag))
                            z = complex(tx,ty) + c
                    hcol = self.cmap[i % self.ncolors]
                    self.mdb.put((hcol,),(xX,yY,xX+1,yY+1))

                    y = y + self.ydiv

                    if self.stopnow:
                        self.updateProgress()
                        self.stopnow=0
                        self._label["text"] = "Finished calculation."
                        self.uil = self.uyl = self.uxl = 0
                        self.calculating=0
                        self.resetter()
                        self.cv["cursor"] = oldcursor
                        self.waitvar.set(0)
                        return
                    if xX != 0 and xX % self.progressize == 0 \
                        and yY == 0:
                        self.updateProgress()
                x = x + self.xdiv
            self.img = self.cv.create_image(self.xresolution/2,
                self.yresolution/2, anchor=CENTER, image=self.mdb)
        self.cv.update()
        self.updateProgress()
        self._label["text"] = "Finished calculation."
        self.mdsize=Msize(self.xresolution,self.yresolution,
            self.xstart,self.ystart,self.xwidth,self.ywidth)

        self.setXYLabels(self.mdsize)
        self.uil = self.uyl = self.uxl = 0
        self.stopnow = 0
        self.calculating=0
        self.cv["cursor"] = oldcursor
        self.waitvar.set(0)

    def changeImages(self,event=0):
        if self.useimages:
            self.useimages=0
        else:
            self.useimages=1
        try:
            self.qbutton.grid_forget()
            self.cbutton.grid_forget()
            self.rbutton.grid_forget()
            self.cabutton.grid_forget()
            del self.qbutton
            del self.cbutton
            del self.rbutton
            del self.cabutton
        except:
            pass
        self.buildAndSetButtons()

    def dithimage(self,f="64-mdb5.gif"):
        if self.mdb != None:
            del self.mdb
        self.mdb = PhotoImage(file=f)
        return self.mdb

    def about(self,event=0):
        d = AboutDialog(self.root)
        root.wait_window(d.top)

    def saveit(self,event=0):
        sname = asksaveasfilename(initialfile="untitled.ppm",
            filetypes=[("PPM files", "*.ppm")])
        if sname and self.mdb:
            self.mdb.write(sname,format="ppm")

    def buildMenu(self):
        bar = Menu(self.root)
        filem = Menu(bar)
        filem.add_command(label="Save as...",command=self.saveit)
        filem.add_command(label="Use button images",
            command=self.changeImages)
        filem.add_separator()
        filem.add_command(label="Exit",command=self.die)
        bar.add_cascade(label="File", menu=filem)
        helpm=Menu(bar)
        helpm.add_command(label="About",command=self.about)
        bar.add_cascade(label="Help", menu=helpm)
        self.root.config(menu=bar)

    def buildButtons(self):
        self.qbutton=Button(self.root,text="Quit",
            command=self.die)
        self.cbutton=Button(self.root,text="Cancel",
            command=self.cancel)
        self.rbutton = Button(self.root,text="Reset",
            command=self.resetter)
        self.cabutton=Button(self.root,text="Calculate",
            command=self.waitcalc)
        if self.useimages:
            self.qimg=PhotoImage(file="x_cimi.gif")
            self.qbutton["image"] = self.qimg
            self.cimg=PhotoImage(file="x_akbal.gif")
            self.cbutton["image"] = self.cimg
            self.rimg=PhotoImage(file="G718.gif")
            self.rbutton["image"] = self.rimg
            self.caimg=PhotoImage(file="xoc_1.gif")
            self.cabutton["image"] = self.caimg

    def buildAndSetButtons(self):
        self.buildButtons()
        self.qbutton.grid(row=0,column=0)
        self.cbutton.grid(row=0,column=1)
        self.rbutton.grid(row=0,column=4)
        self.cabutton.grid(row=0,column=5)

    def buildNColorControl(self):
        f1 = Frame(self.root,width=60,height=32)
        scrollbar = Scrollbar(f1, orient=VERTICAL)
        self.listbox=Listbox(f1,exportselection=0,height=1,
            width=5,yscrollcommand=scrollbar.set,selectmode=SINGLE)
        n = 0
        ns = -1
        for i in self.ncolorlist:
            if i == str(self.ncolors):
               ns = n 
            self.listbox.insert(END,i)
            n = n + 1
        if ns == -1:
            self.ncolorlist.append(str(self.ncolors))
            self.listbox.insert(END,str(self.ncolors))
            ns = n
        scrollbar.config(command=self.listbox.yview)
        self.listbox.pack(side=LEFT)
        scrollbar.pack(side=LEFT)
        self.listbox.select_set(ns)
        self.listbox.see(ns)
        f1.grid(row=0,column=2)
        self.root.columnconfigure(2,minsize=30)

    def buildCMapControl(self):
        f2 = Frame(self.root,width=70,height=32)
        scrollbar1 = Scrollbar(f2, orient=VERTICAL)
        self.listbox1=Listbox(f2,exportselection=0,height=1,
            width=6,yscrollcommand=scrollbar1.set,selectmode=SINGLE)
        k = self.colormaps.keys()
        k.sort()
        for i in k:
            self.listbox1.insert(END,i)
        scrollbar1.config(command=self.listbox1.yview)
        self.listbox1.pack(side=LEFT)
        scrollbar1.pack(side=LEFT)
        self.listbox1.select_set(0)
        f2.grid(row=0,column=3)
        self.root.columnconfigure(3,minsize=70)

    def buildXYLabels(self):
        self.xlab = Label(self.root,text="")
        self.ylab = Label(self.root,text="")
        self.xlab.grid(row=1,column=0,columnspan=3,sticky=W)
        self.ylab.grid(row=1,column=3,columnspan=3,sticky=E)
        self._label=Label(self.root,text="")
        self._label.grid(row=2,column=1,columnspan=5)
        self.zlabel=Label(self.root,text="Zoom:%f" % 1.0)
        self.zlabel.grid(row=2,column=0)

    def buildProgress(self):
        f=Frame(self.root)
        self.progress = Canvas(f,width=self.cxsize,height=16,
            borderwidth=0,highlightthickness=0,selectborderwidth=0)
        self.progress.pack(side=TOP)
        f.grid(row=3,column=0,columnspan=6)

    def buildCanvas(self):
        f = Frame(self.root,width=self.cxsize+54,height=self.cysize+54)

        self.cv = Canvas(f,width=self.cxsize, height=self.cysize,
            borderwidth=0,highlightthickness=0,selectborderwidth=0)
        self.mdb = self.dithimage()
        self.img = self.cv.create_image(self.xresolution/2,
            self.yresolution/2, anchor=CENTER, image=self.mdb)
        self.cv.place(relx=0.5,rely=0.5,anchor=CENTER)
        self.scX = Scale(f,orient=HORIZONTAL,from_=0,
            to=self.xresolution - 1,
            length=self.cxsize, showvalue=0,command=self.xliner)
        self.scX.set(self.xresolution/2)
        self.scX.place(relx=0.5,rely=0,anchor=N)

        self.scY = Scale(f,orient=VERTICAL,from_=0,
            to=self.yresolution - 1,
            length=self.cysize,command=self.yliner, showvalue=0)
        self.scY.set(self.yresolution/2)
        self.scY.place(relx=0,rely=0.5,anchor=W)

        self.scZ = Scale(f,orient=HORIZONTAL,to=0,
            from_=self.yresolution - 1,length=self.cxsize,
            showvalue=0,command=self.zliner)
        self.scZ.set(self.yresolution/2)
        self.scZ.place(relx=0.5,rely=1,anchor=S)
        f.grid(column=0,row=4,columnspan=6)


if __name__ == "__main__":
    if len(sys.argv)>1:
        ncolors=string.atoi(sys.argv[1])
    else:
        ncolors=32
    root=Tk()
    mandel=Mandel(ncolors,root)

    mandel.root.mainloop()

