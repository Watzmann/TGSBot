#!/usr/local/bin/python

import sys
import string

c=-0.5+1j
z=0j

if len(sys.argv)>2:
    r=string.atof(sys.argv[1])
    i=string.atof(sys.argv[2])
    c=complex(r,i)

print "initial value of c", abs(c)
for i in range(64):
    print "step",i,"value of z",z,"distance (abs()) of z",abs(z)
    if abs(z)>2.0:
        break
    z = (z**2) + c
print "color z", i
