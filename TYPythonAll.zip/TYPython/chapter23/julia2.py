#!/usr/local/bin/python

from Tkinter import *
from Canvas import Line,Rectangle
import sys
import string
from colormap import *
from tkFileDialog import *
from mandelbrot2 import *

class Julia(Mandel):
    def __init__(self,ncolors,root,xs=-2.0,ys=-2.0,xw=4.0,yw=4.0,xr=400,yr=400,
        im=["new-mdb.gif", "new-mdb.600.gif", "new-mdb.800.gif",],qn="Lock C",qim=["x_kankin_1.gif","x_pop_1.gif"]):
        Mandel.__init__(self,ncolors,root,xs,ys,xw,yw,xr,yr,im,qn,qim)
        self.calculating=0
        self.center=0j
        self.root.title("Julia Cruiser")
        self.qaction=self.lock
        self.qbutton["command"] = self.qaction
        self.locked=0
        self.xhairs=0j
        self.filem.delete(4)
        self.filem.delete(3)
        self.root.protocol('WM_DELETE_WINDOW',self.killafter)

    def killafter(self):
        self.root.withdraw()

    def lock(self,locker=None):
        if locker != None:
            self.locked=locker
        elif self.locked==0:
            self.locked=1
        else:
            self.locked=0
        if self.locked:
            self.qbutton["text"]="Unlock C"
        else:
            self.qbutton["text"]="Lock C"
        if self.useimages:
            self.qbutton["image"] = self.qimg[self.locked]

    def popJulia(self,event=0):
        pass

    def setXYLabels(self,m=None):
        if not self.__dict__.has_key("center"):
            self.center=0j
            self.xhairs=0j
        if m == None:
            xs = "X start %f width %f xdiv %f" % \
                (self.xstart, self.xwidth, self.xdiv)
            self.xlab["text"] = xs
            ys = "Y start %f width %f ydiv %f" % \
                (self.ystart, self.ywidth, self.ydiv)
            self.ylab["text"] = ys
            self.zlabel["text"]="C = %s\nX = %s\nZoom = %s" % \
                (self.center, self.xhairs, self.xwidth/self.xwidth)
        else:
            xs = "X start %f width %f xdiv %f" % \
                (m.xstart, m.xwidth, m.xdiv)
            self.xlab["text"] = xs
            ys = "Y start %f width %f ydiv %f" % \
                (m.ystart, m.ywidth, m.ydiv)
            self.ylab["text"] = ys
            self.zlabel["text"]="C = %s\nX = %s\nZoom = %s" % \
                (self.center, self.xhairs, self.xwidth/m.xwidth)

    def xliner(self,event=0):
        if self.calculating:
            return
        n=self.scX.get()
        y=self.scY.get()
        x1 = n * self.xdiv
        x1 = self.xstart + x1
        y1 = y * self.ydiv
        y1 = self.ystart + y1
        if not self.locked:
            self.center=complex(x1,y1)
        self.xhairs=complex(x1,y1)
        if self.xdrawn==None:
            self.xdrawn = Line(self.cv,n,0,n,self.yresolution-1,
                fill="#ffffff")
        else:
            self.cv.coords(self.xdrawn,n,0,n,self.yresolution-1)
        self.setXYLabels(self.mdsize)

    def yliner(self,event=0):
        if self.calculating:
            return
        x=self.scX.get()
        n=self.scY.get()
        x1 = x * self.xdiv
        y1 = n * self.ydiv
        x1 = self.xstart + x1
        y1 = self.ystart + y1
        if not self.locked:
            self.center=complex(x1,y1)
        self.xhairs=complex(x1,y1)
        if self.ydrawn==None:
            self.ydrawn = Line(self.cv,0,n,self.xresolution-1,n,
                fill="#ffffff")
        else:
            self.cv.coords(self.ydrawn,0,n,self.xresolution-1,n)
        self.setXYLabels(self.mdsize)

    def zliner(self,event=0):
        if self.calculating:
            return
        self.xliner()
        self.yliner()
        n=self.scZ.get()
        x=self.scX.get()
        y=self.scY.get()
        x1 = x * self.xdiv
        y1 = y * self.ydiv
        x1 = self.xstart + x1
        y1 = self.ystart + y1
        if not self.locked:
            self.center=complex(x1,y1)
        self.xhairs=complex(x1,y1)
        self.setXYLabels(self.mdsize)
        lima = min(x,y)
        limb = min(self.xresolution - x, self.yresolution - y)
        limc = min(lima,limb)
        # x and y are the coordinates of the center.
        # x0 and y0 are the upper left coordinates:
        self.x0 = x - n
        if self.x0 < 0:
            self.x0 = 0
        self.y0 = y - n
        if self.y0 < 0:
            self.y0 = 0
        # x1 and y1 are the lower right coordinates:
        w = x - self.x0
        if w > limc:
            w = limc
        self.x1 = x + w
        if self.x1 > self.xresolution-1:
            self.x1 = self.xresolution-1
        if self.x1 - self.x0 > (limc * 2):
            self.x0 = self.x1 - (limc * 2)
        h = y - self.y0
        if h > limc:
            h = limc
        self.y1 = y + h
        if self.y1 > self.yresolution - 1:
            self.y1 = self.yresolution - 1
        if self.y1 - self.y0 > (limc * 2):
            self.y0 = self.y1 - (limc * 2)
        if x == 0 or y == 0:
            self.x0 = self.y0 = 0
            self.x1 = self.y1 = self.xresolution-1
        if self.x1 - self.x0 == 0 or self.y1 - self.y0 == 0:
            self.x0 = self.y0 = 0
            self.x1 = self.y1 = self.xresolution-1
        if self.zdrawn==None:
            self.zdrawn = Rectangle(self.cv,self.x0,self.y0,
                self.x1,self.y1,outline="#ffffff")
        else:
            self.cv.coords(self.zdrawn,self.x0,self.y0,self.x1,self.y1)
        self.zoomer()

    def resetter(self):
        Mandel.resetter(self)
        self.locked=0
        self.qbutton["text"]="Lock C"
        self.center=0j
        self.xhairs=0j

    def calc(self):
        self.waitvar.set(1)
        self.cv.delete(ALL)
        self.xdrawn=None
        self.ydrawn=None
        self.zdrawn=None
        self.progress.delete(ALL)
        self.mdb = self.dithimage()
        self.img = self.cv.create_image(self.xresolution/2,
            self.yresolution/2, anchor=CENTER, image=self.mdb)
        oldcursor = self.cv["cursor"]
        self.cv["cursor"] = "watch"
        self.calculating=1

        if self.mdsize != None:
            self.xstart,self.ystart,self.xwidth,self.ywidth, \
                self.xend, self.yend,self.xdiv,self.ydiv = \
                self.mdsize()

        x = self.xstart
        self._label["text"] = \
            "Beginning calculation with %d colors %s..." % \
            (self.ncolors,self.cmapname)
        self.cmap = self.cmapcommand(self.ncolors - 1)
        if self.ncolors < 64:
            dwell = 64
        else:
            dwell = self.ncolors
        C = self.center
        self.scX.set(self.xresolution/2)
        self.scY.set(self.yresolution/2)
        self.scZ.set(self.yresolution/2)
        if self.debug == 0:
            for xX in range(self.xresolution):
                y = self.ystart
                for yY in range(self.yresolution):
                    z = complex(x,y)
                    i = 0
                    for i in range(dwell):
                        if abs(z)>2.0:
                            break
                        z=(z**2)+C
                    hcol = self.cmap[i % self.ncolors]
                    self.mdb.put((hcol,),(xX,yY,xX+1,yY+1))

                    y = y + self.ydiv

                    if self.stopnow:
                        self.updateProgress()
                        self.stopnow=0
                        self._label["text"] = "Finished calculation."
                        self.uil = self.uyl = self.uxl = 0
                        self.calculating=0
                        self.resetter()
                        self.cv["cursor"] = oldcursor
                        self.waitvar.set(0)
                        return
                    if xX != 0 and xX % self.progressize == 0 \
                        and yY == 0:
                        self.updateProgress()
                x = x + self.xdiv
            self.img = self.cv.create_image(self.xresolution/2,
                self.yresolution/2, anchor=CENTER, image=self.mdb)
        self.cv.update()
        self.updateProgress()
        self._label["text"] = "Finished calculation."
        self.mdsize=Msize(self.xresolution,self.yresolution,
            self.xstart,self.ystart,self.xwidth,self.ywidth)

        self.setXYLabels(self.mdsize)
        self.uil = self.uyl = self.uxl = 0
        self.stopnow = 0
        self.calculating=0
        self.cv["cursor"] = oldcursor
        self.waitvar.set(0)

    def about(self,event=0):
        d = AboutDialog(self.root,"Julia")
        self.root.wait_window(d.top)

    def clicker(self,event=0):
        x,y=event.x,event.y
        x1=self.xstart+(x*self.xdiv)
        y1=self.ystart+(y*self.ydiv)
        self.scY.set(y)
        self.scX.set(x)

    def clacker(self,event=0):
        pass

if __name__ == "__main__":
    if len(sys.argv)>1:
        ncolors=string.atoi(sys.argv[1])
    else:
        ncolors=32
    root=Tk()
    julia=Julia(ncolors,root)

    julia.root.mainloop()

