#!c:\python\python.exe
import string

class spam:
    def __init__(self):
	self.eggs = 1
    def __del__(self):
	pass
    def __add__(self,other):
	rt = spam()
	rt.eggs = self.eggs + other.eggs
	return rt
    def __coerce__(self,other):
	rt = spam()
	if type(other) == type(rt):
	    return (self,other)
	elif type(other) == type(""):
	    e = string.atoi(other)
	    rt.eggs = e
	    return(self,rt)
	elif type(other) == type(0):
	    rt.eggs = other
	    return(self,rt)
	else:
	    return None
    def __radd__(self,other):
	return self + other
    def __abs__(self):
	return abs(self.eggs)
    def __long__(self):
	return long(self.eggs)
    def __float__(self):
	return float(self.eggs)
    def __int__(self):
	return int(self.eggs)
    def __complex__(self):
	return complex(self.eggs)
    def __divmod__(self,other):
	return divmod(self.eggs,other.eggs)
    def __and__(self,other):
	return self.eggs & other.eggs

if __name__ == "__main__":
    a = spam()
    b = spam()
    a = a + b
    print "a now has", a.eggs, "eggs"
    a = a + "24"
    print "a now has", a.eggs, "eggs"
    a = "24" + a
    print "a now has", a.eggs, "eggs"
    b = b + "13"
    print divmod(a,b)
    print a & b
