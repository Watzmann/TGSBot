#!c:\python\python.exe


class spam:
    def __init__(self):
	pass
    def __del__(self):
	print "I'm about to be deleted!"

a = spam()

def eggspam():
    z = spam()

if __name__ == "__main__":
    print "Calling eggspam()"
    b = eggspam()
    t = []
    for i in range(10):
	t.append(a)

    for i in range(9,-1,-1):
	print "Calling del() on number", i
	del(t[i])

    x = spam()
