#!c:\python\python.exe

import string
import sys

class parrot:
    def __init__(self,s=""):
	self.s = list(s)
    def __repr__(self):
	t = ""
	for i in self.s:
	    t = t + i
	return t
    def __str__(self):
	return parrot.__repr__(self)
    def __add__(self,other):
	rt = parrot(`self`)
	for i in other.s:
	    rt.s.append(i)
	return rt
    def __radd__(self,other):
	return self + other
    def __coerce__(self,other):
	if type(other) == type(self):
	    return (self, other)
	elif type(other) == type(""):
	    rt = parrot(other)
	    return (self, rt)
	elif type(other) == type([]):
	    print "type list"
	    rt = parrot()
	    for i in other:
		if len(i) > 1:
		    for j in i:
			rt.s.append(j)
		else:
		    rt.s.append(i)
	    return (self, rt)
	elif type(other) == type({}):
	    return None
	else:
	    rt = parrot(str(other))
	    return (self, rt)
    def __getitem__(self, key):
	if type(key) == type(0):
	    return self.s[key]
	else:
	   raise TypeError
    def __getslice__(self,i,j):
	s = self.s[i:j]
	t = ""
	for k in s:
	    t = t + k
	return t
    def __setitem__(self, key, value):
	if type(key) == type(0):
	    self.s[key] = value
	else:
	   raise TypeError
    def __setslice__(self,i,j,value):
	self.s[i:j] = list(value)
    def __len__(self):
	return len(self.s)

if __name__ == "__main__":
    if len(sys.argv) > 1:
	s = sys.argv[1]
    else :
	s = "I'm a little teapot!"
    p = parrot(s)
    print p
    q = parrot (" I'm not schizophrenic!")
    print "Add:", p + q
    x = ['N', 'o', ", that bird's not dead", "!"]
    print "Add:", p + ' ' + x
    print "Index[9]: ", p[9]
    print "Index[-9]: ", p[-9]
    p[11], p[13] = p[13], p[11]
    p[14], p[16] = p[16], p[14]
    print p
    pa = p[11:17]
    print pa
    print "Add:", p + ' ' + q
    p[11:17] = "parrot"
    print p, len(p)

