#!/usr/local/bin/python

import os
import sys
import math
import string
import re

_defaultdbfilename = ""

if sys.platform == 'win32' :
    _defaultdbfilename = "/DB/vcrdb"
else :
    _defaultdbfilename = "/bigtmp/DB/vcrdb"

_tsizes = { "T10" : 10,
    "T15" : 15,
    "T20" : 20,
    "T30" : 30,
    "T60" : 60,
    "T90" : 90,
    "T120" : 120,
    "T130" : 130,
    "T160" : 160,
    "T180" : 180,
    "T200" : 200,
  }

_tspeeds = { "sp" : 1, "lp" : 2, "ep" : 3, "slp" : 3, "mx" : 4 }

_yearre = r"[ \t]\([0-9][0-9][0-9][0-9]\)"
_yearrec = 0
_commentre = r" {.*}"
_commentrec = 0
_keywordre = r" \[.*\]"
_keywordrec = 0
_there = r", The$|, A$|, An$|, The\s\(|, The\s\[|, The\s{|, A\s\(|, A\s\[|, A\s{|, An\s\(|, An\s\[|, An\s{"
_therec = 0

def FindYear ( s ) :
    """Search string s for year of the form "(1999)",
    with leading whitespace.  Returns the string without
    the year part, followed by the numeric year.  If there's
    no year, returns None.
    """
    global _yearre
    global _yearrec
    if _yearrec == 0 :
        _yearrec = re.compile ( _yearre )
    so = _yearrec.search ( s )
    if so == None :
        return None
    st, ep = so.span ( )
    st = st + 1 # skip whitespace
    y = string.atoi ( s[ st + 1 : ep - 1 ] )
    rt = s[ : st - 1 ] + s[ ep : ]
    return rt, y

def FindComment ( s ) :
    """Search string s for a comment of the form
    " {comment}"; if not found, return None.  Otherwise,
    return tuple of string with comment removed and
    the comment string.
    """
    global _commentre
    global _commentrec
    if _commentrec == 0 :
        _commentrec = re.compile ( _commentre )
    so = _commentrec.search ( s )
    if so == None :
        return None
    st, ep = so.span ( )
    st = st + 1
    comment = s[ st + 1 : ep - 1 ]
    rt = s[ : st - 1 ] + s[ ep : ]
    return rt, comment

def FindKeyword ( s ) :
    """Search string s for keywords of the form
    " [keywords]".  If not found return None,
    else return tuple of string with keywords
    removed and the string of keywords.
    """
    global _keywordre
    global _keywordrec
    if _keywordrec == 0 :
        _keywordrec = re.compile ( _keywordre )
    so = _keywordrec.search ( s )
    if so == None :
        return None
    st, ep = so.span ( )
    st = st + 1
    keyword = s[ st + 1 : ep - 1 ]
    rt = s[ : st - 1 ] + s[ ep : ]
    return rt, keyword

def SwapThe ( s ) :
    """If string s ends in ", A" or ", An" or ", The", then
    eliminate the comman and prepend A, An or The to the string,
    which is returned.  Otherwise, return the original string.
    """
    if s :
        global _there
        global _therec
        if _therec == 0 :
            _therec = re.compile ( _there )
        so = _therec.search ( s )
        if so == None :
            return s
        st, ep = so.span ( )
        rb = s[ : st ]
        ws = string.strip ( s[ st + 1 : ] )
        if ws[ 0 ] == 'T' :
            rb = "The " + rb
        elif len ( ws ) == 1 :
            rb = "A " + rb
        elif ws[ 0 ] == 'A' and ws[ 1 ] == 'n' :
            rb = "An " + rb
        else :
            rb = "A " + rb
        return rb
    return s

def Extract ( s ) :
    """Searches string s for year, comments and keywords.
    Returns tuple of (string, year, comments, keywords);
    string will have all the others removed, and any item
    not found will be None.
    """
    if s :
        if s[ 0 ] == "\\" :
            ss = s[ 1 : ]
        else :
            ss = s[ : ]
        year = None
        comments = None
        keywords = None
            
        tm = FindYear ( ss )
        if tm != None :
            year = tm[ 1 ]
            ss = tm[ 0 ]
        cm = FindComment ( ss )
        if cm != None :
            comments = cm[ 1 ]
            ss = cm[ 0 ]
        km = FindKeyword ( ss )
        if km != None :
            keywords = km[ 1 ]
            ss = km[ 0 ]
        return ss, year, comments, keywords
    return s

def FindReplaced ( s ) :
    """Searches string s for replacement markers, of the
    form "->1200" and "->1200,1355".  Returns list of the
    cassettes pointed to or None, if there are no replacements.
    """
    i = string.find ( s, "->" )
    n = 0
    if i == 0 :
        i = i + 2
        c = string.find ( s[ i : ], "," )
        if c < 0 :
            try :
                n = string.atoi ( s[ i : ], 0x10 )
            except ValueError :
                return None
            return [ "%04X" % ( n ) ] # make into dict key
        else :
            t = string.splitfields ( s[ i : ], "," )
            tl = [ ]
            for u in t :
                try :
                    n = string.atoi ( u, 0x10 )
                except ValueError :
                    pass
                us = "%04X" % ( n )
                tl.append ( us )
            return tl
    else :
        return None

def speedname ( v ) :
    """Returns the string representing the speed of
    the tape.  200 returns "T200" and so on.  Returns
    None if the speed is bogus.
    """
    for i in _tspeeds.keys ( ) :
        if v == _tspeeds[ i ] :
            return i
    return None

def sizename ( v ) :
    """Returns the string representing the size of
    the tape.  1 returns "sp" and so on.  Returns
    None if the speed is bogus.
    """
    if type ( v ) == type ( "" ) :
        return v
    for i in _tsizes.keys ( ) :
        if v == _tsizes[ i ] :
            return i
    return None

def minutize ( m ) :
    """Converts used tape minutes into string
    representing used minutes or used hours
    and minutes.
    """
    t = int ( m )
    h = t / 60
    hm = t % 60
    if h != 0 :
        if h == 1 :
            ss = ""
        else :
            ss = "s"
        if hm == 1 :
            mm = ""
        else :
            mm = "s"
        s = "%2d hour%s %02d minute%s" % ( h, ss, hm, mm )
    else :
        if t == 1 :
            ss = ""
        else :
            ss = "s"
        s = "%02d minute%s" % ( t, ss )
    return s

def tupleize ( m ) :
    """Converts used tape minutes into tuple
    of hours and minutes.
    """
    t = int ( m )
    h = t / 60
    hm = t % 60
    return ( h, hm )

def tsize ( s ) :
    """Converts name of a tape size (T120, T160, etc.) into a
    number, indicating minutes at sp.  Returns -1 for bogus
    strings.
    """
    if _tsizes.has_key ( s ) :
        return _tsizes[ s ]
    return -1

def tspeed ( s ) :
    """Converts name of a speed (sp, ep, etc.) into
    number--1, 2, etc.  Returns -1 for bogus strings.
    """
    if _tspeeds.has_key ( s ) :
        return _tspeeds[ s ]
    return -1

def header ( s ) :
    """Converts string s into list by splitting on semicolons.
    """
    x = string.splitfields ( s, ";" )
    return x

def parts ( s, n ) :
    """Splits s on "," characters; if there's not two,
    representing used time/time less commercials, raise
    an error.
    """
    x = string.splitfields ( s, "," )
    if len ( x ) != 2 :
        print "Panic: %d 0x%04x:  %s %s %d" % ( n, n, s, x, len ( x ) )
        raise ValueError
    return tuple ( x )

def alldigits ( s ) :
    """Checks s; return a 0 on the first non-digit character found.
    """
    for i in s :
        if i not in string.digits :
            return 0
    return 1

class program :
    def __init__ ( self, s = "", n = 0 ) :
        if s == "" and n == 0 :
            self.seq = -1
            self.year = None
            self.comments = None
            self.keywords = None
            self.rplcd = None
            self.tape = n
        else :
            self.year = None
            self.comments = None
            self.keywords = None
            self.rplcd = None
            self.tape = n
            i = string.index ( s, ":" )
            h = header ( s[ 0 : i ] )
            self.seq = string.atoi ( h[ 0 ] )
            sp, tlen = parts ( h[ 1 ], n )
            self.sp = tspeed ( sp )
            if self.sp == -1 :
                print "UNDEFINED Tape speed:", n, sp
                self.sp = 1 # Default sp
            self.tlen = tsize ( tlen )
            if self.tlen == -1 :
                print "UNDEFINED Tape size:", n, tlen
                self.tlen = _tsizes[ "T120" ]

            self.ttime, self.ctime = tuple ( map ( string.atoi, list ( parts ( h[ 2 ], n ) ) ) )
            stuff = s[ i + 2 : ]
            self.fields = [ ]
            q = string.splitfields ( stuff, ":\t" )
            for k in q :
                if alldigits ( k ) :
                    if k == "" :
                        print h, "empty string", n
                        k = 0
                    self.fields.append ( string.atoi ( k ) )
                else :
                    r = FindReplaced ( k ) # Returns [ list, ]
                    if r != None :
                        self.rplcd = r
                    else :
                        e = Extract ( k )
                        if e == None :
                            print "TAPE %04X Hosed." % ( n )
                            raise ValueError
                        if e[ 1 ] != None :
                            self.year = e[ 1 ]
                        if e[ 2 ] != None :
                            self.comments = e[ 2 ]
                        if e[ 3 ] != None :
                            self.keywords = e[ 3 ]
                        self.fields.append ( e[ 0 ] )

    def __len__ ( self ) :
        return self.ttime

    def speed ( self ) :
        return speedname ( self.sp )

    def size ( self ) :
        return sizename ( self.tlen )

    def __repr__ ( self ) :
        s = "%02d: " % ( self.seq )
        n = 0
        for i in self.fields :
            if type ( i ) == type ( 0 ) :
                s = s + `i`
            else :
                s = s + SwapThe ( i )
                if n == 0 :
                    if self.year != None :
                        s = s + " (%4d)" % ( self.year )
                    if self.comments != None :
                        s = s + " {%s}" % ( self.comments )
                    if self.keywords != None :
                        s = s + " [%s]" % ( self.keywords )
            s = s + ','
            n = n + 1
        return s

def fieldcmp ( l1, l2 ) :
    """Used in sorting.  The usual thing.  -1, 0, 1
    for field comparison.
    """
    ll1 = len ( l1 )
    ll2 = len ( l2 )
    n = max ( ll1, ll2 )
    for pl in range ( 1, n ) : # The field[0]s when we get here are always equal.
        try :
            f1 = l1[ pl ]
        except :
            f1 = None
        try :
            f2 = l2[ pl ]
        except :
            f2 = None
        if f1 != None and f2 == None :
            return -1
        if f1 == None and f2 != None :
            return 1
        if type ( f1 ) == type ( 0 ) and type ( f2 ) == type ( 0 ) :
            if f1 < f2 :
                return -1
            if f1 > f2 :
                return 1
            return fieldcmp ( l1[ pl : ], l2[ pl : ] )
        if type ( f1 ) == type ( "" ) and type ( f2 ) == type ( "" ) :
            if f1 < f2 :
                return -1
            if f1 > f2 :
                return 1
            return fieldcmp ( l1[ pl : ], l2[ pl : ] )
        if type ( f1 ) == type ( 0 ) :
            return 1
        return -1       
    return 0

def alphasort ( p1, p2 ) :
    """Compare programs p1 and p2
    """
    if p1.fields[ 0 ] < p2.fields[ 0 ] :
        return -1
    if p1.fields[ 0 ] > p2.fields[ 0 ] :
        return 1
    return fieldcmp ( p1.fields, p2.fields )

def numsort ( p1, p2 ) :
    """#
    numsort ( p1, p2 ) :
    class program p1, p2
    returns -1, 0 or 1 depending on numeric sequence in tape.
    """
    if p1.tape < p2.tape :
        return -1
    if p2.tape < p1.tape :
        return 1
    if p1.seq < p2.seq :
        return -1
    if p2.seq < p1.seq :
        return 1
    return 0

class cassette :
    def __init__ ( self, n = 0, s = None ) :
        self.num = n
        self.l = { }
        if s == None :
            pass
        else :
            t = program ( s[ 5 : ], self.num )
            self.set ( t )

    def key ( self ) :
        return "%04X" % ( self.num )

    def keys ( self ) :
        if len ( self.l ) == 0 :
            return None
        k = self.l.keys ( )
        k.sort ( )
        return k

    def cat ( self, s ) :
        if s != None :
            t = program ( s[ 5 : ], self.num )
            self.set ( t )

    def __len__ ( self ) :
        t = 0
        k = self.l.keys ( )
        k.sort ( )
        for l in k :
            i = self.l[ l ]
            if i != None :
                t = t + i.ttime
        return t

    def speed ( self ) :
        s = tapespeed ( self )
        return speedname ( s[ 0 ] )

    def size ( self ) :
        return tapesize ( self )

    def programs ( self ) :
        return len ( self.l )

    def programlist ( self ) :
        if isdummy ( self ) :
            return None
        rslt = [ ]
        for i in self.l.keys ( ) :
            rslt.append ( self.l[ i ] )
        return rslt

    def sequence ( self, n ) :
        if type ( n ) == type ( 0 ) :
            k = "%02d" % ( n )
        elif type ( n ) == type ( "" ) :
            k = n
        else :
            k = "%s" % ( n )
        if self.l.has_key ( k ) :
            return self.l[ k ]
        return None

    def set ( self, p ) :
        try :
            n = p.seq
        except AttributeError :
            return
        k = self.sequence ( n )
        if k == None :
            self.l[ "%02d" % ( n ) ] = p
        else :
            self.l[ "%02d" % ( n ) ] = p

    def __repr__ ( self ) :
        s = "%04X\n" % ( self.num )
        if len ( self.l ) == 0 :
            s = s + "*No Tape*"
        else :
            j = self.l.keys ( )
            j.sort ( )
            for k in j :
                i = self.l[ k ]
                s = s + `i` + "\n"
        return s
    
    def nreplaced ( self ) :
        if len ( self.l ) == 0 :
            return 0
        n = 0
        k = self.keys ( )
        for i in k :
            p = self.l[ i ]
            if p.rplcd != None :
                n = n + 1
        return n

    def getreplaced ( self ) :
        if len ( self.l ) == 0 :
            return None
        d = { }
        k = self.keys ( )
        for i in k :
            p = self.l[ i ]
            if p.rplcd != None :
                d[ i ] = p.rplcd
        if len ( d ) == 0 :
            return None
        return d

    def numeric ( self, fld = 0 ) :
        x = self.programlist ( )
        return x

    def alphabetic ( self, fld = 0 ) :
        x = self.programlist ( )
        return x

def isdummy ( t ) :
    """Returns 1 if the cassette t is a dummy record
    0 otherwise.
    """
    if len ( t.l ) == 0 :
        return 1
    return 0

def ismixed ( t ) :
    """class cassette t
    Returns a list containing speeds used in the cassette,
    or None if only one speed is used.
    """
    k = t.keys ( )
    sp = 0
    n = 0
    rt = [ ]
    if isdummy ( t ) :
        return None
    for j in k :
        p = t.sequence ( j )
        if n == 0 :
            sp = p.sp
        else :
            if p.sp != sp :
                if sp not in rt :
                    rt.append ( sp )
                if p.sp not in rt :
                    rt.append ( p.sp )
        n = n + 1
    if len ( rt ) > 0 :
        rt.sort ( )
        return rt
    else :
        return None

def makekey ( n ) :
    """Returns valid shelve dictionary key of 4 hex digits
    from number n.
    """
    if type ( n ) == type ( 0 ) :
        k = "%04X" % ( n )
        return k
    elif type ( n ) == type ( "" ) :
        k = string.upper ( n )
        while len ( k ) < 4 :
            k = "0" + i
        return k
    else :
        raise KeyError

def dummyrecord ( n ) :
    """Creates a dummy cassette--placeholder.
    """
    if type ( n ) == type ( 0 ) :
        x = cassette ( n, None )
    else :
        i = string.atoi ( n, 0x10 )
        x = cassette ( i, None )
    return x

def tapenumber ( s ) :
    """Returns number from string s, where s
    has the form "12D3;......"
    """
    n = string.splitfields ( s, ";" )
    return string.atoi ( n[ 0 ], 0x10 )

def percentoftape ( tp ) :  # A cassette record
    """Returns percent of cassette used.
    """
    n = len ( tp )
    pt = 0.0
    if len ( tp.l ) == 0 :
        return pt
    j = tp.l.keys ( )
    j.sort ( )
    for k in j :  # Program records
        i = tp.l[ k ]
        m = i.sp * i.tlen # total length of tape in speed minutes
        if m == 0 :
            print "Divide by Zero: Tape %s sequence %s" % ( tp.num, i.seq )
            raise ZeroDivisionError
        p = float ( i.ttime ) / float ( m )
        pt = pt + p
    return pt

def percentleft ( tp ) : # Cassette record
    """Returns percent of cassette unused.
    """
    pt = percentoftape ( tp )
    return 1.0 - pt

def tapesize ( tp ) :
    """Returns string representing size of tape;
    T90, T120, etc.
    """
    if isdummy ( tp ) :
        return "T0"
    b = tp.l[ "00" ].tlen
    return sizename ( b )

def tapespeed ( tp ) : # Cassette record
    """Returns tuple of tape speed index
    and length of tape at that speed.
    """
    sp = 0
    tlen = 0
    if isdummy ( tp ) :
        return sp, tlen
    j = tp.l.keys ( )
    j.sort ( )
    for k in j :  # Program records
        i = tp.l[ k ]
        sp = i.sp
        tlen = i.tlen
    return sp, tlen

def minutesleft ( tp ) : # Cassette record
    """Returns minutes left at the ruling tape speed.
    """
    if isdummy ( tp ) :
        return 0.0
    if len ( tp.l ) == 0 :
        return 0.0
    sp, tlen = tapespeed ( tp )
    l = percentleft ( tp )
    mins = sp * tlen # Giving total number of minutes at final tape speed
    m = mins * l
    return m

try :
    _vcrfile = os.environ[ "VCRLIST" ]
except :
    print "$VCRLIST not set in environment!"
    sys.exit ( 0 )

_thedict = { }
global _total_t
_total_t = 0

def creatememdb ( fname = None ) :
    """Creates an in-memory database from the file.
    """
    global _total_t
    global _thedict
    lineno = 0
    commentdict = { }
    nodisc = 0
    if fname == None :
        ff = open ( _vcrfile, "r" )
    else :
        ff = open ( fname, "r" )
        nodisc = 1
    swt = -1
    current_t = -1

    ct = cassette ( -1, None )

    while 1 :
        b = ff.readline ( )
        lineno = lineno + 1
        if not b :
            _thedict[ "%04X" % ( ct.num ) ] = ct
            if swt != current_t :
                _total_t = _total_t + 1
            break
        b = b[ : len ( b ) - 1 ]  # Remove newline
        if len ( b ) < 1 :          # Skip blank lines
            continue

        if b[ 0 ] == '#' :
            ck = "%08d" % ( lineno )
            commentdict[ ck ] = b
            continue
        swt = tapenumber ( b )
        if swt != current_t :
            if ct.num != -1 :
                _thedict[ "%04X" % ( ct.num ) ] = ct
            if nodisc == 0 :
                while swt != current_t + 1 :
                    print "Discontinuity: got 0x%x expected 0x%x" % ( swt, current_t + 1 )
                    current_t = current_t + 1
                    ct = dummyrecord ( current_t )
                    _thedict[ "%04X" % ( ct.num ) ] = ct
                    _total_t = _total_t - 1
            current_t = swt
            ct = cassette ( current_t, b )
            _total_t = _total_t + 1
        else :
            ct.cat ( b )
    if len ( commentdict ) > 0 :
        _thedict[ "COMMENTS" ] = commentdict

    ff.close ( )
    return _thedict, _total_t

import shelve

def createfiledb ( fname = None ) :
    """Create the file database from
    the memory database.
    """
    global _thedict
    global _defaultdbfilename
    if len ( _thedict ) == 0 :
        creatememdb ( fname )
    if fname == None :
        db = shelve.open ( _defaultdbfilename )
    else :
        db = shelve.open ( fname )
    print "Number keys:", len ( _thedict.keys ( ) )
    for i in _thedict.keys ( ) :
        try :
            db[ i ] = _thedict[ i ]
        except :
            print "ERROR.  ERROR"
            print _thedict[ i ]
    db.close ( )
    return db
        
def openfiledb ( fname = None ) :
    global _defaultdbfilename
    if fname == None :
        db = shelve.open ( _defaultdbfilename )
    else :
        db = shelve.open ( fname )
    return db

def closedb ( db ) :
    if type ( db ) == type ( { } ) :
        pass
    else :
        db.close ( )

def getkeys ( vdb ) :
    """Returns the keys for the database.
    """
    if vdb == None :
        return None
    k = vdb.keys ( )
    for i in range ( len ( k ) - 1 ) :
        if k[ i ] == "COMMENTS" :
            k = k[ : i ] + k[ i + 1 : ]
            break
    if "COMMENTS" in k :
        print "COMMENTS NOT REMOVED in", len ( k ), "KEYS", k
        raise IndexError
    return k
        


def findtape ( s, db = None ) :
    """Look for tape s, assumed to be a hex number as a string.
    """
    global _thedict
    i = string.upper ( s )
    while len ( i ) < 4 :
        i = "0" + i
    if db == None :
        try :
            return _thedict[ i ]
        except :
            return None
    else :
        try :
            return db[ i ]
        except :
            return None

def dumptape ( j, vdb ) :
    """Dump the database in the input file format.
    """
    i = findtape ( j, vdb )
    n = i.key ( ) # Already formatted
    ks = i.keys ( ) # List of sequences, in order
    if ks == None :
        sys.stdout.write ( "# %s:\t*NO TAPE*\n" % ( n ) )
        return
    for r in ks :
        p = i.sequence ( r )
        # Use write to prevent trailing space.
        sys.stdout.write ( "%s;%d;%s,%s;%d,%d" % ( n, p.seq, speedname ( p.sp ), sizename ( p.tlen ), p.ttime, p.ctime ), )
        u = 0
        for f in p.fields :
            if type ( f ) == type ( "" ) :
                if alldigits ( f ) :
                    sys.stdout.write ( ":\t\\%s" % ( f ), )
                else :
                    sys.stdout.write ( ":\t%s" % ( f ), )
            else :
                sys.stdout.write ( ":\t%s" % ( f ), )
            if u == 0 and ( p.year or p.comments or p.keywords ) :
                if p.keywords :
                    sys.stdout.write ( " [%s]" % ( p.keywords ), )
                if p.comments :
                    sys.stdout.write ( " {%s}" % ( p.comments ), )
                if p.year :
                    sys.stdout.write ( " (%04d)" % ( p.year ), )
            u = u + 1
        if p.rplcd :
            sys.stdout.write ( ":\t->" )
            nn = len ( p.rplcd )
            nr = 0
            for q in p.rplcd :
                sys.stdout.write ( "%s" % ( q ) )
                if nr != nn - 1 :
                    sys.stdout.write ( "," )
                nr = nr + 1
        sys.stdout.write ( "\n" )

def reprprog ( p ) :
    """Printable string representation of a program object.
    """
    rs = ""
    if p != None :
        rs = rs + "%04X;%d;%s,%s;%d,%d" % ( p.tape, p.seq, speedname ( p.sp ), sizename ( p.tlen ), p.ttime, p.ctime )
        u = 0
        for f in p.fields :
            if type ( f ) == type ( "" ) :
                if alldigits ( f ) :
                    rs = rs + ":\t\\%s" % ( f )
                else :
                    rs = rs + ":\t%s" % ( f )
            else :
                rs = rs + ":\t%s" % ( f )
            if u == 0 and ( p.year or p.comments or p.keywords ) :
                if p.keywords :
                    rs = rs + " [%s]" % ( p.keywords )
                if p.comments :
                    rs = rs + " {%s}" % ( p.comments )
                if p.year :
                    rs = rs + " (%04d)" % ( p.year )
            u = u + 1
        if p.rplcd :
            rs = rs + ":\t->"
            nn = len ( p.rplcd )
            nr = 0
            for q in p.rplcd :
                rs = rs + "%s" % ( q )
                if nr != nn - 1 :
                    rs = rs + ","
                nr = nr + 1
    return rs

def reprtape ( j, vdb ) :
    """Printable string representation of a cassette object.
    """
    rs = ""
    ns = 0
    i = findtape ( j, vdb )
    if i == None :
        rs = "Couldn't find %s in the database." % ( j )
        return rs
    n = i.key ( ) # Already formatted
    ks = i.keys ( ) # List of sequences, in order
    if ks == None :
        rs = "# %s:\t*NO TAPE*" % ( n )
        return rs
    ls = len ( ks ) - 1
    for r in ks :
        p = i.sequence ( r )
        rs = rs + reprprog ( p )
        if ns != ls :
            rs = rs + "\n"
        ns = ns + 1
    return rs

def onlyspeed ( t, ssp ) :
    """Check to see if cassette t is ssp only.
    """
    xl = ismixed ( t )
    if xl == None :
        sp, tlen = tapespeed ( t )
        if ssp == sp :
            return ssp
    return 0

def isspeed ( t, ssp ) :
    """See if cassette t has some or all programs recorded
    at ssp speed.
    """
    xl = ismixed ( t )
    if xl == None :
        sp, tlen = tapespeed ( t )
        if ssp == sp :
            return ssp
    elif ssp in xl :
        return ssp
    return 0

if __name__ == "__main__" :
    if len ( _thedict ) == 0 :
        creatememdb ( )
    print "Total tapes:  %d 0x%x" % ( _total_t, _total_t )
    print "-----------------------------------------"

    createfiledb ( )
    print "-----------------------------------------"

