#!/usr/local/bin/python

import os
import sys
import shelve
import string
from vcr import cassette
from vcr import program
import vcr

try :
    _vcrfile = os.environ[ "VCRLIST" ]
except :
    print "$VCRLIST not set in environment!"
    sys.exit ( 0 )

spd = 0

howmuch = 28.0
lessthan = 9999.0
tlist = [ ]
mlist = [ ]

def prlist ( list ) :
    tpr = 0
    n = len ( list )
    z = 0
    i = 0
    for z in range ( n ) :
	print list[ z ],
	tpr = tpr + 1
	i = z % 3
	if i == 2 :
	    print ""
	else :
	    print "\t",
    if i != 2 :
	print ""
    print "--------------------------------------------------------------------------------"

if len ( sys.argv ) > 1 :
    howmuch = float ( string.atoi ( sys.argv[ 1 ] ) )
    if len ( sys.argv ) > 2 :
	try :
	    lessthan = float ( string.atoi ( sys.argv[ 2 ] ) )
	except :
	    if sys.argv[ 2 ] == "sp" :
		spd = 1
	    elif sys.argv[ 2 ] == "lp" :
		spd = 2
	    elif sys.argv[ 2 ] == "ep" or sys.argv[ 2 ] == "slp" :
		spd = 3
	    else :
		print "I don't understand", sys.argv[ 2 ]
		raise ValueError
    if len ( sys.argv ) > 3 :
	if sys.argv[ 3 ] == "sp" :
	    spd = 1
	elif sys.argv[ 3 ] == "lp" :
	    spd = 2
	elif sys.argv[ 3 ] == "ep" or sys.argv[ 3 ] == "slp" :
	    spd = 3
	else :
	    print "I don't understand", sys.argv[ 3 ]
	    raise ValueError
vdb = vcr.openfiledb ( )
lst = vcr.getkeys ( vdb )
lst.sort ( )
print "Looking for", howmuch, "<", lessthan, "minutes, in", len ( lst ), "Keys"
print "--------------------------------------------------------------------------------"
for j in lst :
    i = vcr.findtape ( j, vdb )
    t = vcr.minutesleft ( i )
    if spd != 0 :
	if not vcr.onlyspeed ( i, spd ) :
	    continue
    if howmuch < t < lessthan :
	x, y = vcr.tapespeed ( i )
	hl, ml = vcr.tupleize ( t )
	st = "T%04X %s -- %03dm %02d:%02d" % ( i.num, vcr.speedname ( x ), t, hl, ml )
	mlist.append ( st )
	st = "%03dm %02d:%02d -- T%04X %s" % ( t, hl, ml, i.num, vcr.speedname ( x ) )
	tlist.append ( st )

tlist.sort ( )
mlist.sort ( )


prlist ( mlist )
prlist ( tlist )

vcr.closedb ( vdb )

