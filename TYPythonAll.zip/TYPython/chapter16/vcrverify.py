#!/usr/local/bin/python

import os
import sys
import string

questionable = """*"""
punctuation = """!@#$%^&*()-_=+[]{}|\\:;"'<>?,./`~"""
goodchars = string.whitespace + string.lowercase + string.uppercase + string.letters + string.digits + string.hexdigits + string.octdigits + punctuation
# Whatever happened to ascii????


badchars = 0
badlines = [ ]

l = len ( sys.argv )
if l > 1 :
    fp = open ( sys.argv[ 1 ], "r" )
    lineno = 0
    while 1 :
	b = fp.readline ( )
	if not b :
	    break
	lineno = lineno + 1
	found = 0
	for i in b :
	    if i not in goodchars :
		badchars = badchars + 1
		found = 1
	if found :
	    badlines.append ( lineno )
    fp.close ( )
    print "file", sys.argv[ 1 ], "contains", lineno, "lines, and", badchars, "bad characters"
    if badchars != 0 :
	print "badlines:", badlines

