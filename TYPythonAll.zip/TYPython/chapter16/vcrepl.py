#!/usr/local/bin/python

import os
import sys
import shelve
import string
import time
from vcr import cassette
from vcr import program
import vcr

try :
    _vcrfile = os.environ[ "VCRLIST" ]
except :
    print "$VCRLIST not set in environment!"
    sys.exit ( 0 )

vdb = vcr.openfiledb ( )
k = vcr.getkeys ( vdb )
k.sort ( )
nrep = 0
nseq = 0
nall = 0
nused = 0
for i in k :
    t = vdb[ i ]
    d = t.getreplaced ( )
    prg = t.programs ( )
    if d != None :
	nrep = nrep + 1
	dk = d.keys ( )
	dk.sort ( )
	for j in dk :
	    p = t.sequence ( j )
	    rtk = d[ j ]
	    print t.key ( ), "sequence", p, "has been replaced by tape ",
	    nseq = nseq + 1
	    z = 0
	    x = len ( rtk )
	    x = x - 1
	    for r in rtk :
		try :
		    rt = vdb[ r ]
		    print rt
		except :
		    print r, "<-invalid"
		if z != x :
		    print "AND by tape ",
		    nseq = nseq + 1
		z = z + 1
    if t.nreplaced ( ) == prg :
	if prg == 0 :
	    print "===>Number %s is available for re-use.\n" % ( t.key ( ) )
	    nused = nused + 1
	else :
	    print "===>Tape %s has been completely replaced.\n" % ( t.key ( ) )
	    nall = nall + 1
print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
print "Tapes with replacements:  %d.  Programs replaced:  %d." % ( nrep, nseq )
print "Tapes completely replaced:  %d.  Numbers not in use:  %d." % ( nall, nused )
print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
vcr.closedb ( vdb )

