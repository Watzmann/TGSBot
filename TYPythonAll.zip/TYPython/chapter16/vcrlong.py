#!/usr/local/bin/python

import os
import sys
import shelve
import string
from vcr import cassette
from vcr import program
import vcr

try :
    _vcrfile = os.environ[ "VCRLIST" ]
except :
    print "$VCRLIST not set in environment!"
    sys.exit ( 0 )


vdb = vcr.openfiledb ( )
lst = vcr.getkeys ( vdb )
lst.sort ( )
for j in lst :
    i = vcr.findtape ( j, vdb )
    sp, tlen = vcr.tapespeed ( i )
    if tlen > 160 :
	print vcr.sizename ( tlen ), i
vcr.closedb ( vdb )

