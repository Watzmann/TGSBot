#!/usr/local/bin/python

import os
import sys
import shelve
import string
from vcr import cassette
from vcr import program
import vcr

try :
    _vcrfile = os.environ[ "VCRLIST" ]
except :
    print "$VCRLIST not set in environment!"
    sys.exit ( 0 )

	
# 0000;0;sp,T90;85,85:	Night in Casablanca, A (1946):	Marx Brothers

ncomments = 0
lcomm = 0

vdb = vcr.openfiledb ( )
lst = vcr.getkeys ( vdb )
comments = vdb[ "COMMENTS" ] 
ckeys = comments.keys ( )
ckeys.sort ( )
lcomm = len ( comments )
lst.sort ( )

lineno = 1
ck = "%08d" % ( lineno )

for j in lst :
    i = vcr.findtape ( j, vdb )
    n = i.key ( ) # Already formatted
    ks = i.keys ( ) # List of sequences, in order
    if ks == None :
	sys.stdout.write ( "# %s:\t*NO TAPE*\n" % ( n ) )
	lineno = lineno + 1
	ck = "%08d" % ( lineno )
	continue
    for r in ks :
	while 1 :
	    if ck in ckeys :
		sys.stdout.write ( "%s\n" % ( comments[ ck ] ) )
		ncomments = ncomments + 1
		del comments[ ck ]
		lineno = lineno + 1
		ck = "%08d" % ( lineno )
	    else :
		lineno = lineno + 1
		ck = "%08d" % ( lineno )
		break
	p = i.sequence ( r )
	# Use write to prevent trailing space.
	sys.stdout.write ( "%s;%d;%s,%s;%d,%d" % ( n, p.seq, vcr.speedname ( p.sp ), vcr.sizename ( p.tlen ), p.ttime, p.ctime ), )
	u = 0
	for f in p.fields :
	    if type ( f ) == type ( "" ) :
		if vcr.alldigits ( f ) :
		    sys.stdout.write ( ":\t\\%s" % ( f ), )
		else :
		    sys.stdout.write ( ":\t%s" % ( f ), )
	    else :
		sys.stdout.write ( ":\t%s" % ( f ), )
	    if u == 0 and ( p.year or p.comments or p.keywords ) :
		if p.keywords :
		    sys.stdout.write ( " [%s]" % ( p.keywords ), )
		if p.comments :
		    sys.stdout.write ( " {%s}" % ( p.comments ), )
		if p.year :
		    sys.stdout.write ( " (%04d)" % ( p.year ), )
	    u = u + 1
	if p.rplcd :
	    sys.stdout.write ( ":\t->" )
	    nn = len ( p.rplcd )
	    nr = 0
	    for q in p.rplcd :
		sys.stdout.write ( "%s" % ( q ) )
		if nr != nn - 1 :
		    sys.stdout.write ( "," )
		nr = nr + 1
	sys.stdout.write ( "\n" )

if len ( comments ) > 0 :
    ckeys = comments.keys ( ) # Account for deleted comments. ...
    ckeys.sort ( )
    for x in ckeys :
	sys.stdout.write ( "%s\n" % ( comments[ x ] ) )
	del comments[ x ]
	ncomments = ncomments + 1

vcr.closedb ( vdb )

# sys.stderr.write ( "Stored comments %d; wrote %d comments to file\n" % ( lcomm, ncomments ) )


