#!c:\python\python.exe

import sys
import os
import errno

if __name__ == "__main__" :
    if len(sys.argv)>1:
        try:
            f=open(sys.argv[1],"rb")
        except:
            x=sys.exc_info()
            print type (x)
            print type(x[0])
            print dir(x[0])
            print type(x[1])
            print dir(x[1])
            print x[1].errno
            print type(x[2])
            print "No file named %s!" % (sys.argv[1],)
            sys.exit(1)
        while1:
            t=f.readline()
            if t=='':
                break
            if '\n' in t:
                t=t[:-1]
            if '\r' in t:
                t=t[:-1]
            sys.stdout.write(t + '\n')
        f.close()
