#!/usr/local/bin/python

import leap2
print __name__
