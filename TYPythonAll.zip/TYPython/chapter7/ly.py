#!c:\python\python.exe

import sys
import string
import leap2

if __name__ == "__main__":
    if len(sys.argv) < 2:
	print "Usage:", sys.argv[0], "year year year..."
	sys.exit(1)
    else:
	for i in sys.argv[1:]:
	    y = string.atoi(i)
	    j = leap2.julian_leap(y)
	    g = leap2.gregorian_leap(y)
	    if j != 0:
		print i, "is leap in the Julian calendar."
	    else:
		print i, "is not leap in the Julian calendar."
	    if g != 0:
		print i, "is leap in the Gregorian calendar."
	    else:
		print i, "is not leap in the Gregorian calendar."


