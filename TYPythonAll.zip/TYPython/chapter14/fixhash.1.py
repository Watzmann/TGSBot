#!c:\python\python.exe
import sys

pbang = "#!" + sys.executable
if sys.platform == "win32" :
    sys.stderr.write ( "Python Version " + sys.version + " Running on Windows\n" )
elif sys.platform == "linux2" :
    sys.stderr.write ( "Python Version " + sys.version + " Running on Linux\n" )
else : 
    sys.stderr.write ( "Python Version " + sys.version + " Running on " + sys.platform + "\n" )

print pbang
