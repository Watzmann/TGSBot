#!/usr/local/bin/python

import sys
import fixhash4


if __name__ == "__main__" :
    nmod = 0
    recurse = 0
    if len ( sys.argv ) > 1 :
	for t in sys.argv[ 1 : ] :
	    if t == '-r' :
		recurse = recurse + 1
	if recurse and len ( sys.argv ) > 2 :
	    dirnames = sys.argv[ 2 : ]
	elif recurse and len ( sys.argv ) < 2 :
	    dirnames = [ "." ]
	else :
	    dirnames = sys.argv[ 1 : ]
    else :
	dirnames = [ "." ]
    print dirnames
    nmod = fixhash4.fixhash ( dirnames, recurse, 1 )

    sys.stderr.write ( "Files modified: " + `nmod` + "\n" )
