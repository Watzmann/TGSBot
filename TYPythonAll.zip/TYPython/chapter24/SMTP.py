#!c:\Python\python.exe
#########################################################################
## This is SMTP sender class. Many thanks to all, which 
## help to finish these useful stuff. If you finds 
## some error, of like to add more features, please feel free 
## to contact with me. Vladimir (gandalf@starship.skyport.net)
##
#########################################################################
## Usage:
## 1) Create SMTP statement and connect to the mailserver:
##    object = SMTP('smtp.server.name.or.address')
## 2) Send message:
##    object.send_message('from_addr', 'to_addr', 'Subject', 'message body')
## 3) You can invoke send_message morethan one times.
## 4) Close connection:
##    object.close()
#########################################################################
## 20-Mar-98 SMTP class bugfix
## All strings into header now finished by '\r'
##               Many thanks to Brian Hooper for this bugfix
## 8-Mar-98 SMTP class modifyed.
## 1) socket creation in __init__ checked by try: except: block.
## 2) In SMTP.check method I'm using SMTP.readline (no more conn.recv :) )
## 3) SMTP.readline uses select call for timeout checking.
##               Many thanks to Skip Montanaro for this update.
########################################################################
## These information will be useful in 'check' method of SMTP instances
##  REPLY CODES BY FUNCTION GROUPS
##         500 Syntax error, command unrecognized
##            [This may include errors such as command line too long]
##         501 Syntax error in parameters or arguments
##         502 Command not implemented
##         503 Bad sequence of commands
##         504 Command parameter not implemented
##
##         211 System status, or system help reply
##         214 Help message
##            [Information on how to use the receiver or the meaning of a
##            particular non-standard command; this reply is useful only
##            to the human user]
##
##         220 <domain> Service ready
##         221 <domain> Service closing transmission channel
##         421 <domain> Service not available,
##             closing transmission channel
##            [This may be a reply to any command if the service knows it
##            must shut down]
##
##         250 Requested mail action okay, completed
##         251 User not local; will forward to <forward-path>
##         450 Requested mail action not taken: mailbox unavailable
##            [E.g., mailbox busy]
##         550 Requested action not taken: mailbox unavailable
##            [E.g., mailbox not found, no access]
##         451 Requested action aborted: error in processing
##         551 User not local; please try <forward-path>
##         452 Requested action not taken: insufficient system storage
##         552 Requested mail action aborted: exceeded storage allocation
##         553 Requested action not taken: mailbox name not allowed
##            [E.g., mailbox syntax incorrect]
##         354 Start mail input; end with <CRLF>.<CRLF>
##         554 Transaction failed
	 
import time, string,select
from socket import * 
 
msg_pattern = """From: %s\r
To: %s\r
Subject: %s\r
Date: %s\r
X-Mailer: Python SMTP class v 1.2\r
\r
%s 
 
""" 
 
 
 
class SMTP: 
	# display a debug message 
	def say(self, msg):  
		s = time.strftime('%c', time.localtime(time.time())) + ': ' + msg 
		print s 
	# 
	def __init__(self, host='localhost', lhost='localhost'):
	    self.error = "SMTP error"
	    try:
		self.conn = socket(AF_INET, SOCK_STREAM)
		self.file = self.conn.makefile()
		self.conn.connect(host, 25) 
		self.check('220') 
		self.send('helo ' + lhost) 
		self.check('250')
	    except socket.error:
		self.conn = None
	# 
	def readline(self):
	     r, w, e = select.select([self.file], [], [], 30)
	     if r == []: raise self.error, "Read from remote host timed out"
	     return r[0].readline()
	def check(self, lev): 
		dat = self.readline()
		if (lev != ''): # means don't care about the result code 
			if dat[:3] != lev: 
				raise self.error, "Unexpected result code!: "+dat
				# what to do here?  Need to exit gracefully, or retry? TBD 
	# 
	def send(self, line): 
		self.conn.send(line + '\n') 
	# 
	def send_body(self, mfrom, mto, subj, body): 
		self.conn.send(msg_pattern%(mfrom, mto, subj, time.ctime(time.time()),body) + '\n' ) 
	# 
	def send_end_of_data(self): 
		#self.say('Sending end of data marker') 
		self.conn.send("\n.\n") 
 
	def send_message(self, mfrom, mto, subj, body): 
		self.send("mail from:<%s>"%mfrom) 
		self.check('250') 
		self.send("rcpt to:<%s>"%mto) 
		self.check('250') 
		self.send("data") 
		self.check('354') 
		self.send_body(mfrom, mto, subj, body) 
		self.send_end_of_data() 
		self.check('250') 
	# 
	def close(self): 
		self.send("quit") 
		self.check('221') 
		self.conn.close() 
	# 
# 
 
if __name__ == '__main__': 
	test_msg = """ 
This is a test of mr. Moukhine :) 
""" 
	import pdb 
        #s = SMTP("folwell.com") 
        #s = SMTP("65-37.lgcit.com")
        s = SMTP("mail.callware.com")
	#pdb.run('s.send("gandalf@rosmail.com", "gandalf@rosmail.com", "Test", "This is a test message.")') 
	#s.send_message("fred@acme.com", "richard@folwell.com", "Test", test_msg)
	#s.send_message("gandalf@lgcit.com", "gandalf@lgcit.com", "Test", test_msg)
	s.send_message("ivanlan@callware.com", "ivanlan@callware.com", "Test", test_msg)
	s.close() 
# 
