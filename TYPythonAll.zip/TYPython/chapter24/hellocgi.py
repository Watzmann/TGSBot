#!c:\Python\python.exe

def print_content():
    print "Content-type: text/html"
    print

def print_header():
    print "<html><title>Pythonic Hello World</title><body>"

def print_footer():
    print "</body></html>"

print_content()
print_header()
print "Hello, World!"
print_footer()

