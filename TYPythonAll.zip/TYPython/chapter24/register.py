#!c:\Python\python.exe
import os
import sys
import cgi
import SMTP

thisscript="http://www.pauahtun.org/cgi-bin/register.py"
mailhost="mail.callware.com"
mailfrom="ivanlan@callware.com"
mailto="ivanlan@callware.com"
ccto="ivanlan@callware.com"

def print_content():
    print "Content-type: text/html"
    print

def print_header():
    print """<html><title>Pythonic Registration Form</title>
    <body bgcolor=white text=black>"""

def print_footer():
    print "</body></html>"

def print_form():
    print """<h1 align=center>Please Register!</h1>
<p>Please register software before downloading it.  Thank you,
%s
<hr>
<p>
<form name=form action=%s method=post>
  Enter your name:
  <input type="edit" name="name"><br>
  Enter your email address:
  <input type="edit" name="email"><br>
  Enter the name of the software you are downloading:
  <input type="edit" name="software"><br>
  Enter the amount you are willing to pay in dollars for the software:
  <input type="edit" name="pay"><br>
  <hr>
  <input type="submit">
  <input type="reset">
</form>
""" % (os.environ["SERVER_NAME"],thisscript)

print_content()
print_header()

form = cgi.FieldStorage()
if form.has_key("name") and form.has_key("email"):
    nm = form["name"].value
    em = form["email"].value
    sw = form["software"].value
    mn = form["pay"].value
    print """<p align=center><font size=7>Thank you!
    </font><font size=3><br>
    <hr>
    """
    print """<p align=left>Thank you %s.  Your email address, %s,
    will shortly receive an invoice for %s dollars, for downloading
    the %s package.  If you do not pay up within 5 business days,
    all your files will be erased.<br>
    <hr>
    <p align=right>Have a nice day<img src="../Gif/smiley.gif">
    """ % (nm,em,mn,sw)
    msg="""Hello, %s (%s):
You recently downloaded %s from %s.
Please send %s dollars immediately to:

Ransom
PO Box 6969
Washington DC 55512
    
If you do not send money, we have a catapult.
Thank you for your attention to this matter.

Anonymous
""" %(nm, em, sw, os.environ["SERVER_NAME"],mn)

    s=SMTP.SMTP(mailhost)
    s.send_message(mailfrom, em,
        "Software Registration", msg)
    s.send_message(mailfrom, ccto,
        "Software Registration", msg)
    s.close()
else:
    print_form()
print_footer()

