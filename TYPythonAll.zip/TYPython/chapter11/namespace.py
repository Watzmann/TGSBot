#!c:\python\python.exe

import sys
import now

z = 666

def f():
    "doc string"
    z = 42
    print dir()

k = sys.modules.keys()
print "Keys:", k
print "---------------"
for i in k:
    if i == "__main__":
	print ">>>", i, "__dict__", sys.modules[i].__dict__

print dir()
print "---------------"
print dir(f)
print "---", "f", dir(sys.modules["__main__"].__dict__["f"])

f()

def d():
    "another doc string"
    z = 44
    x = 9.999
    print dir()

d()

def e():
    "yet another doc string"
    z = 22
    global z
    z = 9999
    print "e", dir()

print z
e()
print z

