#!c:\python\python.exe

import today

if __name__ == "__main__":
    b = []
    for i in range (0,25):
	x = today.today()
	x(i*86400)
	b.append (x)

    print b
