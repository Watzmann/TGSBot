#!c:\python\python.exe

l = ["a", 2, "f", "b", "e", "d", "c", 0, 5]

def srt(a, b):
    if type(a) == type(0) and type(b) == type(0):
	if a < b:
	    return -1
	elif a > b:
	    return 1
	return 0
    if type(a) == type("") and type(b) == type(""):
	if a < b:
	    return -1
	elif a > b:
	    return 1
	return 0
    if type(a) == type(0) and type(b) == type(""):
	return 1
    if type(a) == type("") and type(b) == type(0):
	return -1
    return 0

print l
l.sort()
print l
l.reverse()
print l
l.sort(srt)
print l
