#!c:\python\python.exe

import sys
import string

def printlabel ( n ) :
    s = "%04X" % ( n )
    sys.stdout.write ( "%s\r\n" % ( s ) )
    for i in s :
	sys.stdout.write ( "%s\r\n" % ( i ) )
    sys.stdout.write ( "\r\n" )
    sys.stdout.flush ( )

if __name__ == "__main__" :
    if len ( sys.argv ) > 1 :
	if sys.argv[ 1 ] == "-h" :
	    print """Usage:  lbm start_number quantity
    Example:
	lbm b30 100
    Start_number is hex, quantity is decimal
    if no arguments are given, lbm reads from stdin."""
	    sys.exit ( 0 )
	elif len ( sys.argv ) > 2 :
	    n = string.atoi ( sys.argv[ 1 ], 0x10 )
	    e = string.atoi ( sys.argv[ 2 ] )
#	    sys.stderr.write ( "%s\r\n" % ( range ( n, n + e ) ) )
	    for n in range ( n, n + e ) :
		printlabel ( n )
    else :
	while 1 :
	    p = sys.stdin.readline ( )
	    if not p :
		break
	    n = string.atoi ( p, 0x10 )
	    printlabel ( n )
