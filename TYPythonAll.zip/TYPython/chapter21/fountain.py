#!/usr/local/bin/python

import sys, string

from Tkinter import *
from Canvas import Rectangle,Window
from colormap import *

def die(event=0):
    sys.exit(0)
ncolors = 256
w = 512
h = 64
root = Tk()
cv = Canvas(root,width=w,height=h,borderwidth=0,
    highlightthickness=0)
cmap = Graymap(ncolors)
wd = w / ncolors
x = y = 0
for i in range(ncolors):
    Rectangle(cv,x,y,x+wd,y+h,fill=cmap[i],width=0,outline="")
    x = x+wd
qb=Button(root,text="Quit",command=die)
item=Window(cv,450,32,window=qb)
cv.pack()
root.mainloop()

