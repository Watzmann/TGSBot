#!/usr/local/bin/python

import sys, string

from Tkinter import *
from Canvas import Rectangle,Line,ImageItem,CanvasText
from math import *

w = 128.0
h = 256.0
xp = 0
yp = h
xdelta = 2.0
ydelta = -2.0
wball = None
filename="white.gif"
tm = None

img = None
txt = None

def Radians(x):
    return(x * (pi/180.0E0))

def Degrees(x):
    return(x * (180.0/pi))

def die(event=0):
    sys.exit(0)


def moveball(*args):
    global cv,img,h,w,wball,xp,yp,xdelta,ydelta,tm
    cv.move(wball,xdelta,ydelta)
    if xp >= 0.0 and yp >=0.0:
        if xp >= w:
            xdelta = xdelta * -1.0
        xp = xp + xdelta
        yp = yp + ydelta
        tm = cv.after(10,moveball)
    else:
        cv.delete(wball)
        tm = None

def chsize(event):
    global w,h,xp,yp,xdelta,ydelta
    w = event.width
    h = event.height

def pause(event=0):
    global tm
    cv.after_cancel(tm)

def shoot(event):
    global cv,img,h,w,wball,xp,yp,tm
    global xdelta,ydelta,filename,txt
    img = PhotoImage(file=filename)
    xp = event.x
    yp = event.y
    xdelta = 2.0
    if yp < h/2.0:
        if ydelta < 0:
            ydelta = ydelta * -1.0
    else:
        if ydelta > 0:
            ydelta = ydelta * -1.0
    a = yp - h/2.0
    bw = w - xp
    # A is the angle formed by hypotenuse
    # a is the height of the triangle, side a
    # b is the width of the triangle, side b
    # c is the length of hypotenuse, side c
    # All three trig routines _could_ return 0,
    # so these calls could be put inside a try:
    # except: block.
    A = atan2(a,bw)
    deg = Degrees(A)
    b = 2.0/tan(A)
    xdelta = abs(b)
    cv.delete(wball)
    cv.delete(txt)
    wball = ImageItem(cv,xp,yp,image=img)
    txt = CanvasText(cv,w-25,h-25,font="Helvetica 14",
        text="%02d" % int(deg))
    tm = cv.after(10,moveball)

if __name__ == "__main__":
    root = Tk()
    cv = Canvas(root,width=w,height=h,borderwidth=0,
        background="#409040",
        highlightthickness=0)
    cv.bind("<Configure>", chsize)
    cv.bind("<Button-1>", shoot)
    cv.bind("<Button-3>", pause)
    root.bind("<Escape>", die)
    cv.pack(expand=1,fill=BOTH)
    root.mainloop()

