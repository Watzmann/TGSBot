#!/usr/local/bin/python

from Tkinter import *
from Canvas import Rectangle,Polygon,Window,CanvasText

def GreenCyan():
    global bll,cv
    brl = [0,0xFF,0]
    tmp = bll[:]
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Rectangle(cv,tmp[0],tmp[1],tmp[0]+dg,tmp[1]+4,
            fill=cm,outline="",tag="colorcube")
        tmp[0] = tmp[0] + dg
        brl[2] = (brl[2] + hr) % 0x100

def GreenYellow():
    global bll,cv
    brl = [0,0xFF,0]
    tmp = bll[:]
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Rectangle(cv,tmp[0],tmp[1],tmp[0]+4,tmp[1]-dg,
            fill=cm,outline="",tag="colorcube")
        tmp[1] = tmp[1] - dg
        brl[0] = (brl[0] + hr) % 0x100

def YellowWhite():
    global bul,cv
    brl = [0xFF,0xFF,0]
    tmp = bul[:]
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Rectangle(cv,tmp[0],tmp[1],tmp[0]+dg,tmp[1]+4,
            fill=cm,outline="",tag="colorcube")
        tmp[0] = tmp[0] + dg
        brl[2] = (brl[2] + hr) % 0x100

def WhiteCyan():
    global bur,cv
    brl = [0xFF,0xFF,0xFF]
    tmp = bur[:]
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Rectangle(cv,tmp[0],tmp[1],tmp[0]+4,tmp[1]+dg,
            fill=cm,outline="",tag="colorcube")
        tmp[1] = tmp[1] + dg
        brl[0] = (brl[0] - hr) % 0x100

def BlackBlue():
    global fll,cv
    brl = [0,0,0]
    tmp = fll[:]
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Rectangle(cv,tmp[0],tmp[1],tmp[0]+dg,tmp[1]+4,
            fill=cm,outline="",tag="colorcube")
        tmp[0] = tmp[0] + dg
        brl[2] = (brl[2] + hr) % 0x100

def BlackRed():
    global fll,cv
    brl = [0,0,0]
    tmp = fll[:]
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Rectangle(cv,tmp[0],tmp[1],tmp[0]+4,tmp[1]-dg,
            fill=cm,outline="",tag="colorcube")
        tmp[1] = tmp[1] - dg
        brl[0] = (brl[0] + hr) % 0x100

def RedMagenta():
    global ful,cv
    brl = [0xFF,0,0]
    tmp = ful[:]
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Rectangle(cv,tmp[0],tmp[1],tmp[0]+dg,tmp[1]+4,
            fill=cm,outline="",tag="colorcube")
        tmp[0] = tmp[0] + dg
        brl[2] = (brl[2] + hr) % 0x100

def MagentaBlue():
    global fur,cv
    brl = [0xFF,0,0xFF]
    tmp = fur[:]
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Rectangle(cv,tmp[0],tmp[1],tmp[0]+4,tmp[1]+dg,
            fill=cm,outline="",tag="colorcube")
        tmp[1] = tmp[1] + dg
        brl[0] = (brl[0] - hr) % 0x100

def BlackGreen():
    global fll,cv
    brl = [0,0,0]
    tmp = fll[:]
    eg = dg / 2
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Polygon(cv,
            tmp[0],tmp[1],
            tmp[0]+eg,tmp[1]-eg,
            tmp[0]+eg+3,tmp[1]-eg+3,
            tmp[0]+3,tmp[1]+3,
            fill=cm,outline="",tag="colorcube")
        tmp[0] = tmp[0] + eg
        tmp[1] = tmp[1] - eg
        brl[1] = (brl[1] + hr) % 0x100

def BlueCyan():
    global flr,cv
    brl = [0,0,0xFF]
    eg = dg / 2
    tmp = flr[:]
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Polygon(cv,
            tmp[0],tmp[1],
            tmp[0]+eg,tmp[1]-eg,
            tmp[0]+eg+3,tmp[1]-eg+3,
            tmp[0]+3,tmp[1]+3,
            fill=cm,outline="",tag="colorcube")
        tmp[0] = tmp[0] + eg
        tmp[1] = tmp[1] - eg
        brl[1] = (brl[1] + hr) % 0x100

def RedYellow():
    global ful,cv
    tmp = ful[:]
    brl = [0xFF,0,0]
    eg = dg / 2
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Polygon(cv,
            tmp[0],tmp[1],
            tmp[0]+eg,tmp[1]-eg,
            tmp[0]+eg+3,tmp[1]-eg+3,
            tmp[0]+3,tmp[1]+3,
            fill=cm,outline="",tag="colorcube")
        tmp[0] = tmp[0] + eg
        tmp[1] = tmp[1] - eg
        brl[1] = (brl[1] + hr) % 0x100

def MagentaWhite():
    global fur,cv
    tmp = fur[:]
    brl = [0xFF,0,0xFF]
    eg = dg / 2
    for i in range(ncolors):
        cm = "#%02X%02X%02X" % (brl[0],brl[1],brl[2])
        Polygon(cv,
            tmp[0],tmp[1],
            tmp[0]+eg,tmp[1]-eg,
            tmp[0]+eg+3,tmp[1]-eg+3,
            tmp[0]+3,tmp[1]+3,
            fill=cm,outline="",tag="colorcube")
        tmp[0] = tmp[0] + eg
        tmp[1] = tmp[1] - eg
        brl[1] = (brl[1] + hr) % 0x100

def LabelVertices():
    global cv,fll,flr,blr,bll,ful,fur,bul,bur
    CanvasText(cv,fll[0] - 17,fll[1],text="Black",tag="colorcube")
    CanvasText(cv,flr[0] + 25,flr[1],text="Blue",tag="colorcube")
    CanvasText(cv,blr[0] + 20,blr[1],text="Cyan",tag="colorcube")
    CanvasText(cv,bll[0] - 30,bll[1],text="Green",tag="colorcube")
    CanvasText(cv,ful[0] - 15,ful[1],text="Red",tag="colorcube")
    CanvasText(cv,fur[0] + 40,fur[1],text="Magenta",tag="colorcube")
    CanvasText(cv,bul[0] - 25,bul[1],text="Yellow",tag="colorcube")
    CanvasText(cv,bur[0] + 25,bur[1],text="White",tag="colorcube")

def ColorCube():
    # Back rectangle first:
    GreenCyan()
    GreenYellow()
    YellowWhite()
    WhiteCyan()
    # Diagonals:
    RedYellow()
    BlackGreen()
    MagentaWhite()
    BlueCyan()
    # Front rectangle:
    BlackBlue()
    BlackRed()
    RedMagenta()
    MagentaBlue()
    LabelVertices()

if __name__ == "__main__":
    # Vertices of the rgb cube
    # fll = front lower left;
    # bur = back upper right; etc.
    # The various functions draw
    # the necessary edges.
    fll = [32,468]
    flr = [286,468]
    ful = [32,212]
    fur = [286,212]
    bll = [160,340]
    blr = [412,340]
    bul = [160,84]
    bur = [412,84]


    def die(event=0):
        sys.exit(0)

    root = Tk()

    va = root.winfo_depth()
    if va < 16:
        ncolors = 16
    else:
        ncolors = 32

    hw = 256

    dg = hw/ncolors
    hr = 0x100 / ncolors


    root.title("RGB Color Cube")
    cv = Canvas(root,width=512,height=512,borderwidth=0,
        highlightthickness=0)
    ColorCube()

    button = Button(cv,text="Quit",background="black",
        foreground="red",command=die)
    Window(cv,468,32,window=button)

    cv.pack()

    root.mainloop()

