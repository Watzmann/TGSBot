#!/usr/local/bin/python

import sys
import string

def _value(m,M,hue):
    while hue<0.0:
        hue = hue + 360.0
    while hue > 360.0:
        hue = hue - 360.0
    if hue < 60.0:
        val = m + (M - m) * hue/60.0
    elif hue < 180.0:
        val = M
    elif hue < 240.0:
        val = m + (M - m) * (240.0 - hue)/60.0
    else:
        val = m
    return val

def hls2rgb(h,l,s):
    if l<=0.5:
        M = l * (1.0 + s)
    else:
        M = l + s - l * s
    m = 2.0 * l - M
    r = _value(m,M,h+120.0)
    g = _value(m,M,h)
    b = _value(m,M,h-120.0)
    return (r,g,b)

if __name__ == "__main__":
    if len(sys.argv)< 2:
        print "Usage:", sys.argv[0], "hue lightness saturation"
        sys.exit(0)
    h = string.atof(sys.argv[1])
    l = string.atof(sys.argv[2])
    s = string.atof(sys.argv[3])
    print "rgb=", hls2rgb(h,l,s)
