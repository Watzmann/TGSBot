#!/usr/local/bin/python

from Tkinter import *
from Canvas import Rectangle,Oval,Arc,Window
from colormap import *
import sys

cmap = SetupColormap0(360)

root = Tk()
cv = Canvas(root,width=401,height=401,borderwidth=0,
    highlightthickness=0)
ar = Oval(cv,0,0,400,400)
for i in range(360):
    e = (i + 90) % 360
    ps = Arc(cv,0,0,400,400,start=e,extent=1,fill=cmap[i],outline="")

def die(event=0):
    sys.exit(0)

button=Button(cv,text="Quit",foreground="red",background="black",
    command=die)
Window(cv,380,20,window=button)
cv.pack()

root.mainloop()



