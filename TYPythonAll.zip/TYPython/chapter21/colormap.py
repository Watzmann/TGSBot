#!/usr/local/bin/python

import sys
import string

from hls2rgb import *

def SetupColormap0(ncolors):
    cmap = []
    if ncolors < 3:
        cmap.append("#FFFFFF")
        cmap.append("#000000")
        return cmap
    for i in range(0,ncolors):
        dd = (i * 359.0)/float(ncolors)
        r,g,b = hls2rgb(dd, 0.5, 0.9)
        r = r * 0xFF
        g = g * 0xFF
        b = b * 0xFF
        cmap.append("#%02X%02X%02X" % (r,g,b))
    cmap.append("#000000")
    return cmap

def SetupColormap(ncolors):
    return SetupColormap0(ncolors)

def Graymap(ncolors):
    return SetupColormap6(ncolors)

def SetupColormap1(ncolors):
    cmap = []
    for i in range(0,ncolors):
        dd = (i * 359.0)/float(ncolors)
        r,g,b = hls2rgb(dd, .6, .99)
        r = r * 0xFF
        g = g * 0xFF
        b = b * 0xFF
        cmap.append("#%02X%02X%02X" % (r,g,b))
    cmap.append("#000000")
    return cmap

def SetupColormap2(ncolors):
    cmap = []
    for i in range(0,ncolors):
        dd = (i * 359.0)/float(ncolors)
        r,g,b = hls2rgb(dd, .30, .90)
        r = r * 0xFF
        g = g * 0xFF
        b = b * 0xFF
        cmap.append("#%02X%02X%02X" % (r,g,b))
    cmap.append("#000000")
    return cmap

def SetupColormap3(ncolors):
    cmap = []
    for i in range(0,ncolors):
        dd = (i * 359.0)/float(ncolors)
        if (i < 6):
            r,g,b = hls2rgb(dd, .5, .70)
        else:
            r,g,b = hls2rgb(dd, .6, .90)
        r = r * 0xFF
        g = g * 0xFF
        b = b * 0xFF
        cmap.append("#%02X%02X%02X" % (r,g,b))
    cmap.append("#000000")
    return cmap

def SetupColormap4(ncolors):
    cmap = []
    for i in range(0,ncolors):
        dd = (i * 359.0)/float(ncolors)
        if (i%2):
            r,g,b = hls2rgb(dd, .45, .99)
        else:
            r,g,b = hls2rgb(dd, .55, .99)

        r = r * 0xFF
        g = g * 0xFF
        b = b * 0xFF
        cmap.append("#%02X%02X%02X" % (r,g,b))
    cmap.append("#000000")
    return cmap

def SetupColormap5(ncolors):
    cmap = []
    if ncolors < 3:
        cmap.append("#FFFFFF")
        cmap.append("#000000")
        return cmap
    for i in range(0,ncolors):
        dd = (i * 359.0)/float(ncolors)
        r,g,b = hls2rgb(dd, 0.5, 0.9)
        r = 0xFF - (r * 0xFF)
        g = 0xFF - (g * 0xFF)
        b = 0xFF - (b * 0xFF)
        cmap.append("#%02X%02X%02X" % (r,g,b))
    cmap.append("#000000")
    return cmap

def SetupColormap6(ncolors):
    cmap = []
    xd = 1.0/ncolors
    for i in range(0,ncolors):
        r = g = b = 0xFF - ((i * xd)* 0xFF)
        cmap.append("#%02X%02X%02X" % (r,g,b))
    cmap.append("#000000")
    return cmap

if __name__ == "__main__":
    from Tkinter import *
    from Canvas import Oval,Arc
    from math import *
    ncolors=360
    cwidth = cheight = 401
    cmapcommands=[SetupColormap0,
        SetupColormap1,
        SetupColormap2,
        SetupColormap3,
        SetupColormap4,
        SetupColormap5,
        SetupColormap6,
    ]
    cm = 0
    cmapcom=cmapcommands[cm]

    def die(event=0):
        sys.exit(0)

    def drawcmap(wdg):
        global ncolors,cmap
        ar = Oval(wdg,0,0,400,400)
        dg = 360.0 / ncolors
        for i in range(ncolors):
            e = i * dg
            e = 90.0 + e
            if e > 360.0:
                e = e - 360.0
            ps = Arc(cv,0,0,400,400,start=e,extent=dg,fill=cmap[i],outline="")

    def next(event=0):
        global cmap,cm,cv,cmapcom,cmapcommands,ncolors,lbl
        cm=(cm+1)%len(cmapcommands)
        lbl["text"] = "SetupColormap%d()" % (cm)
        cmapcom=cmapcommands[cm]
        cmap = cmapcom(ncolors)
        cv.delete(ALL)
        drawcmap(cv)

    def prev(event=0):
        global cmap,cm,cv,cmapcom,cmapcommands,ncolors,lbl
        cm=(cm-1)%len(cmapcommands)
        lbl["text"] = "SetupColormap%d()" % (cm)
        cmapcom=cmapcommands[cm]
        cmap = cmapcom(ncolors)
        cv.delete(ALL)
        drawcmap(cv)

    if len(sys.argv)>1:
        ncolors=string.atoi(sys.argv[1])
    if 2 < ncolors < 1101:
        pass
    else:
        print "Can't deal with that many (or few) colors.  Resetting to 360."
        ncolors = 360
    cmap=cmapcom(ncolors)
    root=Tk()
    cv = Canvas(root,width=cwidth,height=cheight,borderwidth=0,
        highlightthickness=0)
    frame=Frame(root)
    qbutton=Button(frame,text="Exit",command=die)
    lbl=Label(frame,text="SetupColormap0()",font="Helvetica 14")
    nextbutton=Button(frame,text="Next",command=next)
    prevbutton=Button(frame,text="Previous",command=prev)
    cv.pack(side=TOP)
    frame.pack(expand=1,fill=BOTH)
    qbutton.pack(side=LEFT)
    lbl.pack(side=LEFT)
    nextbutton.pack(side=RIGHT)
    prevbutton.pack(side=RIGHT)
    
    drawcmap(cv)
    root.mainloop()
