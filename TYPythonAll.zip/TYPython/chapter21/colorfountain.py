#!/usr/local/bin/python

import sys, string

from Tkinter import *
from Canvas import Rectangle,Window
from colormap import *

def die(event=0):
    sys.exit(0)
ncolors = 256
w = 256
h = 256
root = Tk()
frame = Frame(root)
cv = Canvas(frame,width=w,height=h,borderwidth=0,
    highlightthickness=0)
cmap = SetupColormap0(ncolors)
wd = w/ncolors
x = y = 0
for i in range(ncolors):
    Rectangle(cv,x,y,x+wd,y+h,fill=cmap[i],width=0,outline="")
    x = x+wd
qb=Button(frame,text="Exit",command=die,
    foreground="red",background="black")
frame.pack()
cv.pack(side=TOP)
qb.pack(side=LEFT)
root.mainloop()

