#!/usr/local/bin/python 

def spam(n, l=[]): 
    l.append(n) 
    return l 

x =  spam(42) 
print x 
y = spam(39) 
print y 
z = spam(9999, y) 
print x, y, z 
