#include <stdio.h>
#include <time.h>

class now
{
  public:
    time_t t;
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int dow;
    int doy;

    now()
    {
	time(&t);
	struct tm * ttime;
	ttime = localtime(&t);
	year = 1900 + ttime->tm_year;
	month = ttime->tm_mon;
	day = ttime->tm_mday;
	hour = ttime->tm_hour;
	minute = ttime->tm_min;
	second = ttime->tm_sec;
	dow = ttime->tm_wday;
	doy = ttime->tm_yday;
    }
};

main ( int argc, char ** argv )
{
    now x ;
    fprintf ( stdout, "The year is %d\n", x.year ) ;
}
