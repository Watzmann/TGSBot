#!/usr/local/bin/python

from Tkinter import *
import tkMessageBox
import sys

def die(event):
    x = tkMessageBox.Message(root,type=tkMessageBox.ABORTRETRYIGNORE,
        icon=tkMessageBox.QUESTION,
        title="tkMessageBox",
        message="tkMessageBox.askquestion")
    r = x.show()
    tkMessageBox.showinfo("Reply", r )
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()

root.mainloop()
