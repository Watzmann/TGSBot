#!/usr/local/bin/python

from Tkinter import *
import tkMessageBox
import sys

def die(event):
    tkMessageBox.showerror("tkMessageBox","tkMessageBox.showerror")
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()

root.mainloop()
