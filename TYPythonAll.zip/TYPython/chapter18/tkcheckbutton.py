#!/usr/local/bin/python

from Tkinter import *
import sys

def die(event):
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()
checkbutton = Checkbutton(root)
checkbutton["text"] = "Checkbutton"
checkbutton.pack()

root.mainloop()
