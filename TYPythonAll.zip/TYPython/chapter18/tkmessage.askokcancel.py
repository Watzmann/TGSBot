#!/usr/local/bin/python

from Tkinter import *
import tkMessageBox
import sys

def die(event):
    r = tkMessageBox.askokcancel("tkMessageBox","tkMessageBox.askokcancel")
    print r
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()

root.mainloop()
