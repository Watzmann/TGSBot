#!/usr/local/bin/python

from Tkinter import *
import tkMessageBox
import sys

def die():
    sys.exit(0)

def callee():
    print "I was called; few are chosen"

def about():
    tkMessageBox.showinfo("tkmenu","This is tkmenu.py Version 0")
    
root = Tk()
bar = Menu(root)

filem = Menu(bar)
filem.add_command(label="Open...", command=callee)
filem.add_command(label="New...", command=callee)
filem.add_command(label="Save", command=callee)
filem.add_command(label="Save as...", command=callee)
filem.add_separator()
filem.add_command(label="Exit", command=die)

helpm = Menu(bar)
helpm.add_command(label="Index...", command=callee)
helpm.add_separator()
helpm.add_command(label="About", command=about)

bar.add_cascade(label="File", menu=filem)
bar.add_cascade(label="Help", menu=helpm)

root.config(menu=bar)
root.mainloop()

