#!/usr/local/bin/python

from Tkinter import *
import sys

def die(event):
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()
labelx = Label(root)
labelx["height"] = 1
labelx.pack()
label = Label(root)
label["text"] = "Label"
label["borderwidth"] = 1
label["relief"] = SOLID

label.pack()

root.mainloop()
