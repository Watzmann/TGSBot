#!/usr/local/bin/python

from Tkinter import *
import tkMessageBox
import sys

def die(event):
    r = tkMessageBox.askretrycancel("tkMessageBox", \
        "tkMessageBox.askretrycancel")
    print r
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()

root.mainloop()
