#!/usr/local/bin/python

from Tkinter import *
import tkMessageBox
import sys

def die(event):
    tkMessageBox.showinfo("tkMessageBox","tkMessageBox.showinfo")
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()

root.mainloop()
