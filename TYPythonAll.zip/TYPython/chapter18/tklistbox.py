#!/usr/local/bin/python

from Tkinter import *
import sys

elements = [ "item5", "item4", "item3", "item2", "item1" ]

def die(event):
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()
labelx = Label(root)
labelx["height"] = 1
labelx.pack()

listbox = Listbox(root)
for i in elements :
    listbox.insert(0, i)
listbox.pack()

root.mainloop()
