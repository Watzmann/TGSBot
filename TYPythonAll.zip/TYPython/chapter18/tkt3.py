#!/usr/local/bin/python

from Tkinter import *
import sys

root = Tk()
button = Button(root)
button["text"] = "I am a widget"
button.pack()
root.mainloop()

