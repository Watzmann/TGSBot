#!/usr/local/bin/python

from Tkinter import *
import sys

def die(event):
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()
frame = Frame(root)
frame["height"]=64
frame["width"]=64
frame["background"] = "white"
frame["borderwidth"]=2
frame["relief"]=RAISED
frame.pack()

root.mainloop()
