#!/usr/local/bin/python

from Tkinter import *
import sys

def die(event):
    print entry.get()
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()

entry = Entry(root)
entry.insert(0,"Entry")
entry.pack()

root.mainloop()

