#!/usr/local/bin/python

from Tkinter import *
import sys

def die(event):
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()
canvas = Canvas(root)
canvas["height"]=64
canvas["width"]=64
canvas["borderwidth"]=2
canvas["relief"]=RAISED
canvas.pack()

root.mainloop()
