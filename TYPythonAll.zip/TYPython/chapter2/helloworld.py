#!c:\python\python.exe
print "Hello, World!"
print "Goodbye, World!"
