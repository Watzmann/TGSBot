#!/usr/local/bin/python

from Tkinter import *
import sys

def die(event):
    sys.exit(0)

root = Tk()
f = Frame(root)
f.pack(expand=1, fill=BOTH)
button = Button(f,width=25)
button["text"] = "Button"
button.bind("<Button>",die)
button.pack()
t = Text(f,width=25,height=10,relief=RAISED,bd=2)
t.pack(side=LEFT, fill=BOTH, expand=1)

root.mainloop()

