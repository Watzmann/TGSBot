#!/usr/local/bin/python

from Tkinter import *
import sys

wl = []

def die():
    print "You created %d new toplevel widgets" % (len(wl))
    sys.exit(0)

def newwin():
    global root
    wl.append (Toplevel(root))    

root = Tk()
bar = Menu(root)
filem = Menu(bar)
filem.add_command(label="New...", command=newwin)
filem.add_separator()
filem.add_command(label="Exit", command=die)

bar.add_cascade(label="File", menu=filem)
root.config(menu=bar)
root.mainloop()

