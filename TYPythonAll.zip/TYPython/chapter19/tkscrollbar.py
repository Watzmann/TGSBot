#!/usr/local/bin/python

from Tkinter import *
from ScrolledText import *
import sys

def die(event):
    sys.exit(0)

root = Tk()
f = Frame(root)
f.pack(expand=1, fill=BOTH)
button = Button(f,width=25)
button["text"] = "Quit"
button.bind("<Button>",die)
button.pack()

st = ScrolledText(f,background="white")
st.pack()

root.mainloop()

