#!/usr/local/bin/python

from Tkinter import *
import sys
import string

def die(event):
    sys.exit(0)

def reader(s):
    global label
    f = string.atoi(s)
    f = f - 32
    c = f/9.
    c = c * 5.
    flabel["text"] = "Degrees Fahrenheit:  %s" % (s)
    label["text"] = "Degrees Celsius:  %d" % (int(c))

root = Tk()
button = Button(root,width=25)
button["text"] = "Quit"
button.bind("<Button>",die)
button.pack()

flabel = Label(root,text="Degrees Fahrenheit:")
flabel.pack(anchor=W)
scale2 = Scale(root, orient=VERTICAL,from_=-40,to=212,command=reader)
scale2.pack()
label = Label(root,text="Degrees Celsius:")
label.pack(anchor=W)

root.title("Fahrenheit to Celsius")

root.mainloop()

