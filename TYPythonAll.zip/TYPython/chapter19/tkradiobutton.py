#!/usr/local/bin/python

from Tkinter import *
import sys

def die(event):
    global v, periods
    print periods[v.get()][0]
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Quit"
button.bind("<Button>",die)
button.pack()

v = IntVar()
v.set(2)

periods = [
    ("kin", 0),
    ("uinal", 1),
    ("tun", 2),
    ("katun", 3),
    ("baktun", 4),
]

if len(sys.argv) > 1:
    indicator = 0
    filler=X
    expander=1
else:
    indicator = 1
    filler=None
    expander=0
for t, m in periods :
    b = Radiobutton(root,text=t, variable=v, value=m, indicatoron=indicator)
    if indicator == 1 :
        b.pack(anchor=W)
    else :
        b.pack(expand=expander,fill=filler)

root.mainloop()
