#!/usr/local/bin/python

from Tkinter import *
from ScrolledText import *
import tkMessageBox
from tkFileDialog import *
import fileinput

st = None

def die():
    sys.exit(0)

def openfile():
    global st
    pl = END
    oname = askopenfilename(filetypes=[("Python files", "*.py")])
    if oname:
        for line in fileinput.input(oname):
            st.insert(pl,line)
        
def savefile():
    sname = asksaveasfilename()
    if sname:
        ofp = open(sname,"w")
        ofp.write(st.get(1.0,END))
        ofp.flush()
        ofp.close()

def about():
    tkMessageBox.showinfo("Tkeditor", "Simple tkeditor Version 0\n"
        "Written 1999\n"
        "For Teach Yourself Python in 24 Hours")


if __name__ == "__main__":
    global st
    root = Tk()
    bar = Menu(root)

    filem = Menu(bar)
    filem.add_command(label="Open...", command=openfile)
    filem.add_command(label="Save as...", command=savefile)
    filem.add_separator()
    filem.add_command(label="Exit", command=die)

    helpm = Menu(bar)
    helpm.add_command(label="About", command=about)

    bar.add_cascade(label="File", menu=filem)
    bar.add_cascade(label="Help", menu=helpm)
    root.config(menu=bar)

    f = Frame(root,width=512)
    f.pack(expand=1, fill=BOTH)

    st = ScrolledText(f,background="white")
    st.pack(side=LEFT, fill=BOTH, expand=1)
    root.mainloop()
