#!/usr/local/bin/python

from Tkinter import *
from ScrolledText import *
import tkMessageBox
from tkFileDialog import *
import fileinput

tl = []
root = None

def die():
    sys.exit(0)

def about():
    tkMessageBox.showinfo("Tkeditor", "Simple tkeditor Version 1\n"
        "Written 1999\n"
        "For Teach Yourself Python in 24 Hours")

class editor:
    def __init__(self, rt):
        if rt == None:
            self.t = Tk()
        else:
            self.t = Toplevel(rt)
        self.t.title("Tkeditor %d" % len(tl))
        self.bar = Menu(rt)

        self.filem = Menu(self.bar)
        self.filem.add_command(label="Open...", command=self.openfile)
        self.filem.add_command(label="New...", command=neweditor)
        self.filem.add_command(label="Save as...", command=self.savefile)
        self.filem.add_command(label="Close", command=self.close)
        self.filem.add_separator()
        self.filem.add_command(label="Exit", command=die)

        self.helpm = Menu(self.bar)
        self.helpm.add_command(label="About", command=about)

        self.bar.add_cascade(label="File", menu=self.filem)
        self.bar.add_cascade(label="Help", menu=self.helpm)
        self.t.config(menu=self.bar)

        self.f = Frame(self.t,width=512)
        self.f.pack(expand=1, fill=BOTH)

        self.st = ScrolledText(self.f,background="white")
        self.st.pack(side=LEFT, fill=BOTH, expand=1)

    def close(self):
        self.t.destroy()

    def openfile(self):
        pl = END
        oname = askopenfilename(filetypes=[("Python files", "*.py")])
        if oname:
            for line in fileinput.input(oname):
                self.st.insert(pl,line)
            self.t.title(oname)
        
    def savefile(self):
        sname = asksaveasfilename()
        if sname:
            ofp = open(sname,"w")
            ofp.write(self.st.get(1.0,END))
            ofp.flush()
            ofp.close()
            self.t.title(sname)

def neweditor():
    global root
    tl.append(editor(root))

if __name__ == "__main__":
    root = None
    tl.append(editor(root))
    root = tl[0].t
    root.mainloop()
