#!/usr/local/bin/python

from Tkinter import *
import sys
import string

def die(event):
    sys.exit(0)

def reader(s):
    f = string.atoi(s)
    f = f - 32
    c = f/9.
    c = c * 5.
    print "%s degrees F = %f degrees C" % (s, c)

root = Tk()
button = Button(root)
button["text"] = "Quit"
button.bind("<Button>",die)
button.pack()

scale1 = Scale(root, orient=HORIZONTAL)
scale1.pack()
scale2 = Scale(root, orient=VERTICAL,from_=-40,to=212,command=reader)
scale2.pack()

root.mainloop()

