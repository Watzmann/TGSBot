#!c:\python\python.exe

import imptest1

x = imptest1.today()
print x
print dir()
print dir(imptest1)

try:
    print _CHANGEOVER
except:
    try:
	print imptest1._CHANGEOVER
    except:
	print "Can't find _CHANGEOVER"
