#!c:\python\python.exe

_CHANGEOVER="Sep 3 1752"

from today import *
