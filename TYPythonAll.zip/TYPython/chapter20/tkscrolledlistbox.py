#!/usr/local/bin/python

from Tkinter import *
import sys
import os
import string

def setn(event):
    global elements
    global listbox
    global lb
    global img
    x = listbox.curselection()
    n = string.atoi(x[0])
    img = PhotoImage(file=elements[n])
    lb["image"] = img

def listgifs(d="."):
    l = os.listdir(d)
    rl = []
    for i in l:
        t = string.lower(i)
        g = string.rfind(t,".gif")
        if g >= 0:
            rl.append(i)
    if len(rl)<1:
        rl = None
    else:
        rl.sort()
    return rl

def die(event):
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Quit"
button.bind("<Button>",die)
button.pack()
labelx = Label(root)
labelx["height"] = 1
labelx.pack()

elements = listgifs()

frame = Frame(root,bd=2,relief=SUNKEN)
frame.pack(expand=1,fill=BOTH)
scrollbar = Scrollbar(frame, orient=VERTICAL)
listbox = Listbox(frame,exportselection=0,height=10,
    yscrollcommand=scrollbar.set)
listbox.bind("<Double-Button-1>",setn)
for i in elements :
    listbox.insert(END, i)
scrollbar.config(command=listbox.yview)
listbox.pack(side=LEFT)
scrollbar.pack(side=LEFT, fill=Y)
listbox.select_set(0)
listbox.see(0)
lb = Label(root,text="No gif")
lb.pack()

root.mainloop()
