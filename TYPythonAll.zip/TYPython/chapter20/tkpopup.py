#!/usr/local/bin/python

from Tkinter import *
import string
import sys

def die(event=None):
    sys.exit(0)

def getxy(something):
    s = something.geometry()
    return map(int, string.splitfields(s[1+string.find(s,"+"):],'+'))

def new_file(event=None):
    print "Opening new file"

def open_file(event=None):
    print "Opening existing file"

def activate_menu(event=None):
    x, y = getxy(root)    
    menu.tk_popup(x+event.x, y+event.y)

root = Tk()
root.canvas = Canvas(root, height=100, width=100)
root.canvas.pack()
menu = Menu(root)
menu.add_command(label="New...", underline=0, command=new_file)
menu.add_command(label="Open...", underline=0, command=open_file)
menu.add_separator()
menu.add_command(label="Exit...", underline=0, command=die)
menu['tearoff'] = 0

root.canvas.bind("<Button-3>", activate_menu)

root.mainloop()

