#!/usr/local/bin/python

from Tkinter import *
import sys
from tkFileDialog import *
import os
import string
#import Image, ImageTk

def buildmenu(xx=0):
    global pwd
    global root
    global lg
    global bar
    if pwd != None:
        lg = listgifs()
        if lg != None:
            n = len(lg)
            gifm = Menu(bar)
            if n < 20:
                n = 0
                for i in lg:
                    gifm.add_command(label=i,
                      command = lambda m=i: setimage(m))
                    n = n + 1
            else:
                nm = n / 20
                no = n % 20
                if no:
                    nm = nm + 1
                for i in range(nm):
                    tm = Menu(gifm)
                    if i == nm - 1 and no != 0:
                        lim = no
                    else:
                        lim = 20
                    for j in range(lim):
                        ne = (20 * i) + j
                        tm.add_command(label=lg[ne],
                          command=lambda m=lg[ne]:setimage(m))
                    gifm.add_cascade(label="List gifs %d"%(i),menu=tm)

            if xx == 0:
                bar.delete(2)
            bar.add_cascade(label="Gifs",menu=gifm)    

class MyDialog:
    def __init__(self, parent,txt):
        top = self.top = Toplevel(parent)
        Label(top, text="Enter new directory").pack()
        self.e = Entry(top)
        self.e.insert(0,txt)
        self.e.pack(padx=5)
        b = Button(top, text="OK", command=self.ok)
        b.pack(pady=5)

    def ok(self):
        global pwd
        global root
        global lg
        npwd = self.e.get()
        if npwd and npwd != "":
            pwd = npwd
            os.chdir(pwd)
            root.title(pwd)
            buildmenu()
        self.top.destroy()

def cd():
    global pwd
    global root
    d = MyDialog(root,pwd)
    root.wait_window(d.top)

def listgifs(d="."):
    l = os.listdir(d)
    rl = []
    for i in l:
        t = string.lower(i)
        g = string.rfind(t,".gif")
        if g >= 0:
            rl.append(i)
    if len(rl)<1:
        rl = None
    else:
        rl.sort()
    return rl

def setimage(s):
    global lg
    global img
    global pwd
    if s in lg:
        _label["image"] = img = PhotoImage(file=s)
        pwd = os.getcwd()
        root.title(pwd+'/'+s)

def die():
    sys.exit(0)

def sv():
    global _label
    global img
    pl = END
    oname = asksaveasfilename(initialfile="untitled.ppm",filetypes=[
        ("PPM files", "*.ppm"),
    ])
    if oname:
        try:
            img.write(oname,format="ppm")
        except:
            ig = PhotoImage()
            print "PhotoImage() succeeded"

def ls():
    global _label
    global img
    pl = END
    oname = askopenfilename(filetypes=[("Gif files", "*.gif"),
        ("Jpeg files", "*.jpg"),
        ("PNG files", "*.png"),
        ("PPM files", "*.ppm"),
        ("XBM files", "*.xbm"),
        ("All files", "*.*")
    ])
    if oname:
        try:
            _label["image"] = img = PhotoImage(file=oname)
        except:
            _label["image"] = img = BitmapImage(file=oname)
        root.title(oname)

def main():
    global _label,img,root
    global lg
    global pwd
    global gifm
    global bar
    global img
    img = None
    lg = listgifs()
    root = Tk()
    if len(sys.argv)>1:
        fn = sys.argv[1]
        img = PhotoImage(file=fn)
    else:
        try:
            fn = "X_oc.gif"
            img = PhotoImage(file=fn)
        except:
            if lg and lg[0]:
                fn = lg[0]
                img = PhotoImage(file=fn)
    pwd = os.getcwd()
    root.title(pwd+'/'+fn)
    bar = Menu(root)
    filem = Menu(bar)
    filem.add_command(label="Open...",command=ls)
    filem.add_command(label="Save as...",command=sv)
    filem.add_command(label="Change directory...",command=cd)
    filem.add_separator()
    filem.add_command(label="Exit",command=die)
    
    bar.add_cascade(label="File", menu=filem)
    if lg != None:
        buildmenu(1)
    else:
        bar.add_cascade(label="None")
    root.config(menu=bar)
    if img:
        _label = Label(root,image=img)
    else:
        _label = Label(root,text="No gif files found")
    _label.pack()

    root.mainloop()

if __name__ == "__main__":
    main()

