#!/usr/local/bin/python

from Tkinter import *
import os
import string

img = None

def die():
    sys.exit(0)

def listgifs(d="."):
    l = os.listdir(d)
    rl = []
    for i in l:
        t = string.lower(i)
        g = string.rfind(t,".gif")
        if g >= 0:
            rl.append(i)
    if len(rl)<1:
        rl = None
    else:
        rl.sort()
    return rl

def setimage(s):
    global elements
    global lb
    global img
    if s in elements:
        img = PhotoImage(file=s)
        lb["image"] = img

def main():
    global elements
    global lb
    elements = listgifs()
    if not elements:
        print "No gifs"
    n = len(elements)
    nm = n / 10
    no = n % 10
    if no:
        nm = nm + 1
    print "For %d files, I'll make %d menus" % ( n, nm )
    root = Tk()
    mb = Menu(root)
    cb = Menu(mb)
    cb.add_command(label="Exit",command=die)

    gm = Menu(mb)
    for i in range(nm):
        tm = Menu(gm)
        if i == nm - 1 and no != 0:
            lim = no
        else:
            lim = 10
        for j in range(lim):
            ne = (10 * i) + j
            tm.add_command(label=elements[ne],
                command=lambda m=elements[ne]:setimage(m))
        gm.add_cascade(label="List gifs %d" % (i),menu=tm)

    mb.add_cascade(label="File", menu=cb)
    mb.add_cascade(label="Gifs", menu=gm)

    lb = Label(root,text="No gif")
    lb.pack()
    root.config(menu=mb)
    root.mainloop()

if __name__ == "__main__":
    main()
