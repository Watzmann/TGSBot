#!/usr/local/bin/python

import sys
from Tkinter import *

def die(event):
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Ave atque vale!"
button.bind("<Button-1>", die)
button.pack()
root.mainloop()
