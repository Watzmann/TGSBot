#!/usr/local/bin/python

import sys
from Tkinter import *

def die(event=0):
    sys.exit(0)

def prn(s):
    print "I'm the", s, "button"

class Gridder:
    def __init__(self,w):
        global death
        names=["A","B","C",
            "D","E","F",
            "G","H","I",
            ]
        n = 0
        for i in range(3):
            for j in range(3):
                item=Button(w,text=names[n])
                if names[n] == "E":
                    item["command"] = die
                    item["image"] = death
                else:
                    item["command"] = lambda x=names[n] : prn(x)
                item.grid(row=i,column=j,sticky=E+W+N+S)
                n = n+1

class Packer:
    def __init__(self,w):
        global death
        n = 0
        self.a = Frame(w)
        self.a.pack(side=TOP,expand=1,fill=BOTH)
        for i in range(3):
            item=Button(self.a,text=`n`)
            item.pack(side=LEFT,expand=1,fill=BOTH)
            item["command"] = lambda x=n : prn(x)
            n = n+1
        self.b = Frame(w)
        self.b.pack(side=TOP,expand=1,fill=BOTH)
        for i in range(3):
            item=Button(self.b,text=`n`)
            item.pack(side=LEFT,expand=1,fill=BOTH)
            if i == 1:
                item["command"] = die
                item["image"] = death
            else:
                item["command"] = lambda x=n : prn(x)
            n = n+1
        self.c = Frame(w)
        self.c.pack(side=TOP,expand=1,fill=BOTH)
        for i in range(3):
            item=Button(self.c,text=`n`)
            item.pack(side=LEFT,expand=1,fill=BOTH)
            item["command"] = lambda x=n : prn(x)
            n = n+1
    
class Placer:
    def __init__(self,w):
        global death
        opts=[(N,0.5,0),
            (NE,1,0),
            (E,1,0.5),
            (SE,1,1),
            (S,0.5,1),
            (SW,0,1),
            (W,0,0.5),
            (NW,0,0),
            (CENTER,0.5,0.5),
            ]
        for an,xx,yy in (opts):
            item=Button(w,text=an)
            item.place(relx=xx,rely=yy,anchor=an)
            if an == CENTER:
                item["command"] = die
                item["image"] = death
            else:
                item["command"] = lambda x=an : prn(x)

root=Tk()

death = PhotoImage(file="x_cimi.gif")

pl=Toplevel(root)
pl.title("Place")
plc = Placer(pl)

pa=Toplevel(root)
pa.title("Pack")
pac = Packer(pa)

gr=Toplevel(root)
gr.title("Grid")
grc = Gridder(gr)


root.withdraw()
root.mainloop()

