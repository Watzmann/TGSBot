#!/usr/local/bin/python

import sys, string, random
from Tkinter import *
from Canvas import ImageItem,Rectangle,CanvasText
from colormap import *

class Glyphs(Frame):
    def die(self,event=0):
        sys.exit(0)

    def __init__(self,parent=None,nobj=0,wwidth=640,wheight=480):
        self.pause=0
        self.xdelta=[]
        self.ydelta=[]
        self.xmin = 16
        self.ymin = 16
        self.windowwidth = wwidth
        self.windowheight = wheight
        self.xlim=self.windowwidth - self.xmin
        self.ylim=self.windowheight - self.ymin
        self.xpos=[]
        self.ypos=[]
        self.img = []
        self.pictures = []
        self.deltav = 1
        self.parent=parent
        Frame.__init__(self, self.parent)
        Pack.config(self)

        self.nobj = nobj
        self.buildglyphs(nobj)

    def buildglyphs(self,n=1):
        self.ncolors = 128
        self.cmap = SetupColormap1(self.ncolors)

        self.draw = Canvas(self,
            width=self.windowwidth, height=self.windowheight)
        self.llabel=CanvasText(self.draw,self.windowwidth - 100,
            self.windowheight - 32, text="",font="Helvetica 20")
        self.parent.bind("<Escape>",self.die)
        sr = 1+(self.windowheight / self.ncolors)
        x = 0
        y = 0
        w = self.windowwidth
        for c in self.cmap:
            if c == "#000000":
                break
            item=Rectangle(self.draw,x,y,w,y+sr,fill=c,
                outline="",width=0)
            y = y + sr
        self.draw.pack()

if __name__ == "__main__":
    wwidth=-1
    wheight=-1
    if len(sys.argv) > 1:
        nobj=string.atoi(sys.argv[1])
        if len(sys.argv) > 3:
            wwidth=string.atoi(sys.argv[2])
            wheight=string.atoi(sys.argv[3])
    else:
        nobj=-1
    root=Tk()
    if wwidth == -1:
        wwidth=root.winfo_screenwidth()
        wheight=root.winfo_screenheight()
    if nobj == 1:
        suff=""
    else:
        suff=" Brothers"
    root.title("Flying Glyph" + suff)
    glyphs = Glyphs(root,nobj,wwidth,wheight)

    glyphs.mainloop()
