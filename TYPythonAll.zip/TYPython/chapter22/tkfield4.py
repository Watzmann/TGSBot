#!/usr/local/bin/python

import sys, string, random
from Tkinter import *
from Canvas import ImageItem,Rectangle,CanvasText
from colormap import *

class Glyphs(Frame):
    def die(self,event=0):
        sys.exit(0)

    def snap(self,event=0):
        if self.pause == 0:
            self.pause=1
        else:
            self.pause=0

    def lifter(self,event=0):
        x = self.draw.gettags(CURRENT)
        if len(x)==1:
            return
        self.llabel["text"]=x[0]
        self.draw.lift(self.llabel)
        y = self.draw.find_withtag(x[0])
        if y:
            self.draw.lift(y[0])

    def __init__(self,parent=None,nobj=0,wwidth=640,wheight=480):
        self.smallglyphlist = ["x_ahau.gif","x_imix.gif","x_ik.gif",
            "x_akbal.gif", "x_kan.gif", "x_chicchan.gif", "x_cimi.gif",
            "x_manik.gif", "x_lamat.gif", "x_muluk.gif", "x_oc.gif",
            "x_chuen.gif", "x_eb.gif", "x_ben.gif", "x_ix.gif",
            "x_men.gif", "x_cib.gif", "x_caban.gif", "x_etznab.gif",
            "x_cauac.gif",
        ]
        self.bigglyphlist = ["ahau_m.gif","imix_m.gif","ik_m.gif",
            "akbal_m.gif", "kan_m.gif", "chicchan_m.gif", "cimi_m.gif",
            "manik_m.gif", "lamat_m.gif", "muluk_m.gif", "oc_m.gif",
            "chuen_m.gif", "eb_m.gif", "ben_m.gif", "ix_m.gif",
            "men_m.gif", "cib_m.gif", "caban_m.gif", "etznab_m.gif",
            "cauac_m.gif",
        ]
        self.pause=0
        self.xdelta=[]
        self.ydelta=[]
        self.xmin = 16
        self.ymin = 16
        self.windowwidth = wwidth
        self.windowheight = wheight
        self.xlim=self.windowwidth - self.xmin
        self.ylim=self.windowheight - self.ymin
        if self.windowwidth < 800:
            self.glyphlist = self.smallglyphlist
        else:
            self.glyphlist=self.bigglyphlist
        self.xpos=[]
        self.ypos=[]
        self.img = []
        self.pictures = []
        self.deltav = 1
        self.parent=parent
        Frame.__init__(self, self.parent)
        Pack.config(self)

        if nobj<0 or nobj>len(self.glyphlist):
            nobj=len(self.glyphlist)
        self.nobj = nobj
        self.buildglyphs(nobj)

    def buildglyphs(self,n=1):
        self.ncolors = 128
        self.cmap = SetupColormap0(self.ncolors)

        self.draw = Canvas(self,
            width=self.windowwidth, height=self.windowheight)
        self.llabel=CanvasText(self.draw,self.windowwidth - 100,
            self.windowheight - 32, text="",font="Helvetica 20")
        self.parent.bind("<Escape>",self.die)
        self.parent.bind("<Button-1>",self.snap)
        self.parent.bind("<Button-3>",self.lifter)
        sr = 1+(self.windowheight / self.ncolors)
        x = 0
        y = 0
        w = self.windowwidth
        for c in self.cmap:
            if c == "#000000":
                break
            item=Rectangle(self.draw,x,y,w,y+sr,fill=c,
                outline="",width=0)
            y = y + sr

        self.deltav = self.windowwidth/128 + 1

        for i in range(n):
            self.img.append(PhotoImage(file=self.glyphlist[i]))
            if i == 0:
                self.xmin = self.img[i].width()/2
                self.ymin = self.img[i].height()/2
                self.xlim=self.windowwidth - self.xmin
                self.ylim=self.windowheight - self.ymin

            if i%2==0:
                self.xdelta.append(self.deltav)
                self.ydelta.append(self.deltav)
            else:
                self.xdelta.append(-self.deltav)
                self.ydelta.append(-self.deltav)

            self.xpos.append(random.randint(self.xmin,self.xlim))
            self.ypos.append(random.randint(self.ymin,self.ylim))

            self.pictures.append(ImageItem(self.draw,self.xpos[i],
                self.ypos[i], image=self.img[i],
                tags=self.glyphlist[i]))

        self.draw.pack()
        self.after(10, self.moveglyphs)

    def moveglyphs(self, *args):
        if self.pause==1:
            self.after(10, self.moveglyphs)
            return
            
        for n in range(self.nobj):
            self.draw.move(self.glyphlist[n], self.xdelta[n],
                self.ydelta[n])
            tmp = self.xpos[n] + self.xdelta[n]
            if tmp > self.xlim or tmp < self.xmin:
                self.xdelta[n] = self.xdelta[n] * -1
                self.xdelta[n] = self.xdelta[n] + \
                    random.choice((0,1)) - 2
                if self.xdelta[n] == 0:
                    self.xdelta[n] = self.xdelta[n] + 1
            self.xpos[n] = self.xpos[n] + self.xdelta[n]
            
            tmp = self.ypos[n] + self.ydelta[n]
            if tmp > self.ylim or tmp < self.ymin:
                self.ydelta[n] = self.ydelta[n] * -1
                self.ydelta[n] = self.ydelta[n] + \
                    random.choice((0,1)) - 2
                if self.ydelta[n] == 0:
                    self.ydelta[n] = self.ydelta[n] + 1
            self.ypos[n] = self.ypos[n] + self.ydelta[n]

        self.after(10, self.moveglyphs)

if __name__ == "__main__":
    wwidth=-1
    wheight=-1
    if len(sys.argv) > 1:
        nobj=string.atoi(sys.argv[1])
        if len(sys.argv) > 3:
            wwidth=string.atoi(sys.argv[2])
            wheight=string.atoi(sys.argv[3])
    else:
        nobj=-1
    root=Tk()
    if wwidth == -1:
        wwidth=root.winfo_screenwidth()
        wheight=root.winfo_screenheight()
    if nobj == 1:
        suff=""
    else:
        suff=" Brothers"
    root.title("Flying Glyph" + suff)
    glyphs = Glyphs(root,nobj,wwidth,wheight)

    glyphs.mainloop()
