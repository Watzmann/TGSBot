#!/usr/local/bin/python
from Tkinter import *
import sys

def die(event=0):
    sys.exit(0)

x = Button(None,text="Hello, World!",command=die)
x.pack()
x.mainloop()

