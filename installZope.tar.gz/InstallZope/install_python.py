#!/usr/bin/python
# -*- coding: utf-8 -*-

import os.path
from subprocess import Popen, PIPE, call
from ConfigParser import ConfigParser
import general

BUFSIZE = 4096

class Python:

    def __init__(self, version, pil='pil-1.1.6'):
        self.exist = ''
        self.version = version
        self.pil_version = pil
        self.settings = general.read_settings(sections=['python','packets',])
        if not version:
            return

        self.force_installation = False
        
        label = '.'.join(version.split('.')[:2])    # 2.3.5 -> 2.3
        cmd = 'which python'    # Installationspfad von python ermitteln
        p = Popen(cmd, shell=True, bufsize=BUFSIZE, stdout=PIPE,).stdout
        python = p.read().splitlines()[0] + label
        p.close()

        # Annahme:
        #   wenn zu "version" (z.B. 2.3.5) eine Installation existiert,
        #   dann existiert ein <prefix>/python2.x (z.B. <prefix>/python2.3)
        if os.path.exists(python):
            cmd = python + ' -V'    # Tatsächliche Version ermitteln
            p = Popen(cmd, shell=True, bufsize=BUFSIZE, stderr=PIPE,).stderr
            python = p.read().splitlines()[0].split()[1]
            p.close()
            self.exist = True
            self.version = python

    def print_settings(self,):
        general.print_settings(self.settings)

    def install(self):
        if self.exist and not self.force_installation:
            print 'found existing version', self.version
            return
        else:
            print 'Installing Python', self.version
            general.preparations(self.settings)
            self.settings['this_install_root'] = \
                os.path.join(self.settings['install_root'],'Python-'+self.version)
            self.settings['logfile_root'] = \
                os.path.join(self.settings['log_dir'],'python-'+self.version)
            self.unpacking()
            self.configure()

    def install_pil(self, version=''):
        if version == '':
            version = self.pil_version
        if not version.startswith('pil-'):
            version = 'pil-' + version
        #...
        
    def unpacking(self, check=False):
        st = self.settings
        packet = os.path.join(st['sources'],st[self.version])
        st['packet'] = packet
        ok = os.path.exists(packet)
        if not ok:
            print 'ERROR: cannot find', packet
        elif check:
            print 'found', packet
        else:
            print 'unpacking', st[self.version]
            #general.print_settings(st)
            if os.path.exists(st['this_install_root']):
                cmd = 'rm -rf %(this_install_root)s' % st
                #print cmd
                retcode = call(cmd.split())
                #print retcode, '(for >%s...)' % cmd[:15]
            cmd = 'tar xjf %(packet)s -C %(install_root)s' % st
            print cmd
            retcode = call(cmd.split())
            #print retcode, '(for >%s...)' % cmd[:15]
        return

    def configure(self,):
        print 'about to configure ...'
        params = self.settings.copy()
        params['configure'] = os.path.join(params['this_install_root'],'configure')
        params['logfile'] = params['logfile_root'] + '-configure'
        #general.print_settings(params)
        cmd = '%(configure)s --prefix=%(prefix)s > %(logfile)s 2>&1' % params
        print cmd
        retcode = call(cmd, shell=True)
##        print 'returned with',retcode

##        p = Popen(cmd, shell=True, bufsize=BUFSIZE, stdout=PIPE,).stdout
##        python = p.read().splitlines()[0] + label
##        p.close()
        
        
if __name__ == '__main__':
    Python('').print_settings()
    
##    for v in ['2.3','2.4','2.5',]:  #'2.6.1',]:
##        f = Python(v)
##        if f.exist:
##            print 'found', f.version, '(looking for %s)' % v
##        else:
##            f.install()

    f = Python('2.3.5')
    f.force_installation = True
    f.install()
