#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import sys
from subprocess import call
from ConfigParser import ConfigParser

def preparations(settings):
    instdir = settings.get('install_root', False)
    logdir = settings.get('log_dir', False)
    for d in (instdir, logdir):
        if d and not os.path.exists(d):
            os.makedirs(d)
            print 'created', d
        elif d and os.path.exists(d) and not os.path.isdir(d):
            print 'ERROR:', d, 'exists and no directory!!!'
            sys.exit(1)
        if not write_permission(d):
            print 'ERROR: no write permission in %s' % d
            sys.exit(1)
    
def read_settings(sections=[]):
    config = ConfigParser()
    files = ['installzope.conf', os.path.expanduser('~/.installzope'),] # /etc/installzope.conf
    config.read(files)
    settings = dict(config.items('general'))
    for s in sections:
        settings.update(dict(config.items(s)))
    return settings

def print_settings(settings):
    print '- settings ' + '-'*20
    for k,v in settings.items():
        print k,'=',v
    print '-'*30

def write_permission(path):
    if path and os.path.exists(path) and not os.path.isdir(path):
        print 'WARNING: path is not a directory (%s)' % path
        return False
    ah = os.path.join(path,'ah')
    cmd = 'touch %s > /dev/null 2>&1' % ah
    ret = call(cmd, shell=True)
    if os.path.exists(ah):
        os.remove(ah)
    return ret == 0
